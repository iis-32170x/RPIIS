#include <iostream>
#include <string>
#include <vector>
#include <limits>
#include <unistd.h>
#include <ctime>

using std::cout, std::cin, std::string, std::endl, std::vector, std::ostream, std::istream, std::streamsize, std::numeric_limits;

template <typename Type>
Type check_key()
{
    Type number;

    while (1)
    {
        cin >> number;

        if (cin.fail())
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Incorrect input! Try again " << endl;
        }
        else
        {
            cin.clear();
            break;
        }
    }

    return number;
}

template <typename Type2>
void show_list(vector<Type2> list)
{
    for (int i = 0; i < list.size(); i++)
    {
        cout << i + 1 << ". " << list[i] << endl;
    }
}

// Человек
class Human
{
private:
    string gender;

public:
    Human();
    virtual ~Human();

    virtual void tell_about_yourself() const;
    friend ostream &operator<<(ostream &os, const Human &man);

    void set_gender(string gender);
    string get_gender() const;
};

// Сотрудник
class Employee : public Human
{
private:
    string name;
    string surname;
    string fathers_name;
    long int phone_number;
    string post;

public:
    Employee();
    ~Employee();

    virtual void tell_about_yourself() const override;
    friend ostream &operator<<(ostream &os, const Employee &employee);

    void set_name(string name);
    void set_surname(string name);
    void set_fathers_name(string fathers_name);
    void set_phone_number(long int phone_number);
    void set_post(string post);
    string get_name() const;
    string get_surname() const;
    string get_fathers_name() const;
    long int get_phone_number() const;
    string get_post() const;

    virtual void work();
};

// Студент
class Student : public Human
{
private:
    string name;
    int hours_skipped;
    int scholarship;
    double average_mark;

public:
    Student();
    ~Student();

    virtual void tell_about_yourself() const override;
    friend ostream &operator<<(ostream &os, const Student &student);

    void set_name(string name);
    void set_hours_skipped(int hours_skipped);
    void set_scholarship(int salary);
    void set_average_mark(double mark);
    string get_name() const;
    int get_hours_skipped() const;
    int get_scholarship() const;
    double get_average_mark() const;

    virtual void study();
};

// Дисциплина
class Subject
{
private:
    string name;
    int hours_to_study;

public:
    Subject();
    ~Subject();

    friend ostream &operator<<(ostream &os, const Subject &sbj);

    void set_name(string name);
    void set_hours_to_study(int hours_to_study);
    string get_name() const;
    int get_hours_to_sudy() const;
};

// Экзамен
class Exam
{
private:
    int hour;
    int day;
    int year;
    Subject subject;

public:
    Exam();
    ~Exam();

    friend ostream &operator<<(ostream &os, const Exam &exam);

    void set_hour(int hour);
    void set_day(int day);
    void set_year(int year);
    void set_subject(Subject sbj);
    int get_hour() const;
    int get_day() const;
    int get_year() const;
    Subject get_subject() const;

    vector<Student> change_marks(vector<Student> students);
};

// Группа
class Group
{
private:
    int number;
    Employee curator;
    vector<Student> list_of_students;

public:
    Group();
    ~Group();

    friend ostream &operator<<(ostream &os, const Group &grp);

    void set_number(int number);
    void set_curator(Employee curator);
    void set_list_of_students(vector<Student> list_of_students);

    int get_number() const;
    Employee get_curator() const;
    vector<Student> get_list_of_students() const;

    void sort_students();
};

// Учитель
class Teacher : public Employee
{
private:
    int salary;
    Subject subject;

public:
    Teacher();
    ~Teacher();

    friend ostream &operator<<(ostream &os, const Teacher &tch);
    virtual void tell_about_yourself() const override;

    void set_salary(int salary);
    int get_salary() const;
    void set_subject(Subject subject);
    Subject get_subject() const;

    void add_skipped_hours(vector<Student> &students);

    virtual void work() override;
};

// Кафедра
class Department
{
private:
    string name;
    vector<Group> list_of_groups;
    vector<Employee> list_of_employees;
    vector<Subject> list_of_subjects;
    vector<Exam> list_of_exams;

public:
    Department();
    ~Department();

    friend ostream &operator<<(ostream &os, const Department &dep);

    void set_name(string name);
    void set_list_of_groups(vector<Group> list_of_groups);
    void set_list_of_employees(vector<Employee> list_of_employees);
    void set_list_of_subjects(vector<Subject> sbjcts);
    void set_list_of_exams(vector<Exam> exm);
    string get_name() const;
    vector<Group> get_list_of_groups() const;
    vector<Employee> get_list_of_employees() const;
    vector<Subject> get_list_of_subjects() const;
    vector<Exam> get_list_of_exams() const;

    void add_student(Student stdnt);
    void remove_student();
    void add_employee(Employee emp);
    void remove_employee();
    void add_subject(Subject sbj);
    void remove_subject();
    void add_exam(Exam exm);
    void remove_exam();
};

// Стипендия
class Scholarship
{
private:
public:
    Scholarship();
    ~Scholarship();

    void set_scholarship(vector<Student> &students);
    void change_scholarship(vector<Student> &students);
};

// Этаж
class Floor
{
private:
    Department dep;
    vector<int> offices;
    int floor_height;

public:
    Floor();
    ~Floor();

    friend ostream &operator<<(ostream &os, const Floor &fl);

    void set_department(Department dep);
    void set_offices(vector<int> offcs);
    void set_floor_height(int height);
    Department get_department() const;
    vector<int> get_offices() const;
    int get_floor_height() const;
};

// Корпус
class Building
{
private:
    string street;
    int number;
    vector<Floor> floors;

public:
    Building();
    ~Building();

    friend ostream &operator<<(ostream &os, const Building &bld);

    void set_street(string strt);
    void set_number(int nmr);
    void set_floors(vector<Floor> floors);
    string get_street() const;
    int get_number() const;
    vector<Floor> get_floors() const;
};

// Декан
class Dean : public Employee
{
private:
    Building building;

public:
    Dean();
    ~Dean();

    friend ostream &operator<<(ostream &os, const Dean &dn);
    void who_are_you(const Human *human) const;

    void set_bld(Building building);
    Building get_bld() const;
};

// Деканат
class Dean_office
{
private:
    Dean dean;

public:
    Dean_office();
    ~Dean_office();

    friend ostream &operator<<(ostream &os, const Dean_office &deanof);

    void set_dean(Dean dean);
    Dean get_dean() const;
};

// Факультет
class Faculty
{
private:
    Dean_office deanof;
    string name;

public:
    Faculty();
    ~Faculty();

    friend ostream &operator<<(ostream &os, const Faculty &name);

    void set_dean_office(Dean_office deanof);
    void set_name(string name);
    string get_name() const;
    Dean_office get_dean_office() const;
};

// R Человек
Human::Human()
{
    this->gender = "";
}
Human::~Human() {}
ostream &operator<<(ostream &os, const Human &hm)
{
    os << "Human; Gender: " << hm.gender;
    return os;
}
void Human::set_gender(string gender)
{
    this->gender = gender;
}
string Human::get_gender() const { return this->gender; }
void Human::tell_about_yourself() const
{
    cout << "I'm just a human; I'm " << this->gender << endl;
}

// R Сотрудник
Employee::Employee()
{
    this->name = "";
    this->surname = "";
    this->fathers_name = "";
    this->phone_number = 0;
    this->post = "";
}
Employee::~Employee() {}
void Employee::tell_about_yourself() const
{
    cout << "I'm employee; " << *this << "; Phone: " << phone_number
         << "; Post: " << post << endl;
}
ostream &operator<<(ostream &os, const Employee &employee)
{
    os << "Employee; FIO: " << employee.name << " " << employee.surname << " " << employee.fathers_name;
    return os;
}
void Employee::set_name(string name)
{
    this->name = name;
}
void Employee::set_surname(string surname)
{
    this->surname = surname;
}
void Employee::set_fathers_name(string fathers_name)
{
    this->fathers_name = fathers_name;
}
void Employee::set_phone_number(long int phone_number)
{
    this->phone_number = phone_number;
}
void Employee::set_post(string post)
{
    this->post = post;
}
string Employee::get_name() const { return this->name; }
string Employee::get_surname() const { return this->surname; }
string Employee::get_fathers_name() const { return this->fathers_name; }
long int Employee::get_phone_number() const { return this->phone_number; }
string Employee::get_post() const { return this->post; }
void Employee::work()
{
    cout << "This employee is doing some work" << endl;
    sleep(2);
}

// R Студент
Student::Student()
{
    this->name = "";
    this->hours_skipped = 0;
    this->scholarship = 0;
    this->average_mark = 0;
}
Student::~Student() {}
void Student::tell_about_yourself() const
{
    cout << "I'm student; " << *this << "; Skipped hours: " << hours_skipped
         << "; Scholarship: " << scholarship << "; Average mark: " << average_mark << endl;
}
ostream &operator<<(ostream &os, const Student &student)
{
    os << "Student; Name: " << student.name;
    return os;
}
void Student::set_name(string name)
{
    this->name = name;
}
void Student::set_hours_skipped(int hours_skipped)
{
    this->hours_skipped = hours_skipped;
}
void Student::set_scholarship(int salary)
{
    this->scholarship = salary;
}
void Student::set_average_mark(double mark)
{
    this->average_mark = mark;
}
string Student::get_name() const { return this->name; }
int Student::get_hours_skipped() const { return this->hours_skipped; }
int Student::get_scholarship() const { return this->scholarship; }
double Student::get_average_mark() const { return this->average_mark; }
void Student::study()
{
    if (average_mark + 0.05 < 10)
    {
        cout << "Student is learning" << endl;
        average_mark += 0.05;
    }
    else
    {
        cout << "Student has best mark" << endl;
    }
}

// R Группа
Group::Group()
{
    this->number = 0;
}
Group::~Group() {}
ostream &operator<<(ostream &os, const Group &grp)
{
    os << "Group; Number: " << grp.number;
    return os;
}
void Group::set_number(int number)
{
    this->number = number;
}
void Group::set_curator(Employee curator)
{
    this->curator = curator;
}
void Group::set_list_of_students(vector<Student> list_of_students)
{
    this->list_of_students = list_of_students;
}
int Group::get_number() const { return this->number; }
Employee Group::get_curator() const { return this->curator; }
vector<Student> Group::get_list_of_students() const { return this->list_of_students; }
void Group::sort_students()
{
    cout << "1 - sort by name; 2 - sort by average mark: ";
    int i;
    do
    {
        i = check_key<int>();
    } while (i < 1 || i > 2);
    if (i == 1)
    {
        Student k;
        for (int i = 0; i < list_of_students.size() - 1; i++)
        {
            for (int j = 1; i < list_of_students.size(); i++)
            {
                if (list_of_students[i].get_name() > list_of_students[j].get_name())
                {
                    k = list_of_students[i];
                    list_of_students[i] = list_of_students[j];
                    list_of_students[j] = k;
                }
            }
        }
    }
    else
    {
        Student k;
        for (int i = 0; i < list_of_students.size() - 1; i++)
        {
            for (int j = 1; i < list_of_students.size(); i++)
            {
                if (list_of_students[i].get_average_mark() > list_of_students[j].get_average_mark())
                {
                    k = list_of_students[i];
                    list_of_students[i] = list_of_students[j];
                    list_of_students[j] = k;
                }
            }
        }
    }
}

// R Кафедра
Department::Department()
{
    this->name = "";
}
Department::~Department() {}
ostream &operator<<(ostream &os, const Department &dep)
{
    os << "Department; Name: " << dep.name;
    return os;
}
void Department::set_name(string name)
{
    this->name = name;
}
void Department::set_list_of_employees(vector<Employee> list_of_employees)
{
    this->list_of_employees = list_of_employees;
}
void Department::set_list_of_groups(vector<Group> list_of_groups)
{
    this->list_of_groups = list_of_groups;
}
void Department::set_list_of_subjects(vector<Subject> sbjcts)
{
    this->list_of_subjects = sbjcts;
}
void Department::set_list_of_exams(vector<Exam> exms)
{
    this->list_of_exams = exms;
}
string Department::get_name() const { return this->name; }
vector<Employee> Department::get_list_of_employees() const { return this->list_of_employees; }
vector<Group> Department::get_list_of_groups() const { return this->list_of_groups; }
vector<Subject> Department::get_list_of_subjects() const { return this->list_of_subjects; }
vector<Exam> Department::get_list_of_exams() const { return this->list_of_exams; }
void Department::add_student(Student stdnt)
{
    show_list<Group>(list_of_groups);
    int i;
    cout << "Choose group position: ";
    do
    {
        i = check_key<int>();
    } while (i < 1 || i > list_of_groups.size());
    i--;
    vector<Student> temp = list_of_groups[i].get_list_of_students();
    temp.push_back(stdnt);
    list_of_groups[i].set_list_of_students(temp);
}
void Department::remove_student()
{
    show_list<Group>(list_of_groups);
    int i;
    cout << "Choose group position: ";
    do
    {
        i = check_key<int>();
    } while (i < 1 || i > list_of_groups.size());
    i--;
    vector<Student> temp = list_of_groups[i].get_list_of_students();
    show_list<Student>(temp);
    int i2;
    cout << "Choose student position: ";
    do
    {
        i2 = check_key<int>();
    } while (i2 < 1 || i2 > temp.size());
    i2--;
    temp.erase(next(temp.begin(), i2));
    list_of_groups[i].set_list_of_students(temp);
}
void Department::add_employee(Employee emp)
{
    list_of_employees.push_back(emp);
}
void Department::remove_employee()
{
    show_list<Employee>(list_of_employees);
    int i2;
    cout << "Choose employee position: ";
    do
    {
        i2 = check_key<int>();
    } while (i2 < 1 || i2 > list_of_employees.size());
    i2--;
    list_of_employees.erase(next(list_of_employees.begin(), i2));
}
void Department::add_subject(Subject sbj)
{
    list_of_subjects.push_back(sbj);
}
void Department::remove_subject()
{
    show_list<Subject>(list_of_subjects);
    int i2;
    cout << "Choose subject position: ";
    do
    {
        i2 = check_key<int>();
    } while (i2 < 1 || i2 > list_of_subjects.size());
    i2--;
    list_of_subjects.erase(next(list_of_subjects.begin(), i2));
}
void Department::add_exam(Exam exm)
{
    list_of_exams.push_back(exm);
}
void Department::remove_exam()
{
    show_list<Exam>(list_of_exams);
    int i2;
    cout << "Choose exam position: ";
    do
    {
        i2 = check_key<int>();
    } while (i2 < 1 || i2 > list_of_exams.size());
    i2--;
    list_of_exams.erase(next(list_of_exams.begin(), i2));
}

// R Дисциплина
Subject::Subject()
{
    this->hours_to_study = 0;
    this->name = "";
}
Subject::~Subject() {}
ostream &operator<<(ostream &os, const Subject &sbj)
{
    os << "Subject; Name: " << sbj.name;
    return os;
}
void Subject::set_hours_to_study(int hours_to_study)
{
    this->hours_to_study = hours_to_study;
}
void Subject::set_name(string name)
{
    this->name = name;
}
int Subject::get_hours_to_sudy() const { return this->hours_to_study; }
string Subject::get_name() const { return this->name; }

// R Учитель
Teacher::Teacher()
{
    this->salary = 0;
}
Teacher::~Teacher() {}
ostream &operator<<(ostream &os, const Teacher &tchr)
{
    os << "Teacher; Name: " << tchr.get_name();
    return os;
}
void Teacher::tell_about_yourself() const
{
    cout << "I'm teacher; " << *this << "; Salary: " << this->salary << endl;
}
void Teacher::set_salary(int salary)
{
    this->salary = salary;
}
void Teacher::set_subject(Subject subject)
{
    this->subject = subject;
}
int Teacher::get_salary() const { return this->salary; }
Subject Teacher::get_subject() const { return this->subject; }
void Teacher::add_skipped_hours(vector<Student> &students)
{
    show_list<Student>(students);
    cout << "Choose student's number: ";
    int i;
    cin >> i;
    i--;
    students[i].set_hours_skipped(students[i].get_hours_skipped() + 2);
}
void Teacher::work()
{
    sleep(2);
    this->salary += 4;
}

// R Декан
Dean::Dean()
{
}
Dean::~Dean() {}
ostream &operator<<(ostream &os, const Dean &dean)
{
    os << "Dean; Name: " << dean.get_name();
    return os;
}
void Dean::who_are_you(const Human *human) const
{
    human->tell_about_yourself();
}

// R стипендия
Scholarship::Scholarship() {}
Scholarship::~Scholarship() {}
void Scholarship(vector<Student> &students)
{
    for (int i = 0; i < students.size(); i++)
    {
        if (students[i].get_hours_skipped() > 9)
        {
            students[i].set_scholarship(0);
        }
    }
}
void Scholarship::change_scholarship(vector<Student> &students)
{
    show_list<Student>(students);
    cout << "Choose number: ";
    int i;
    cin >> i;
    i--;
    cout << "Enter change of scholrship (+/-): ";
    int c;
    cin >> c;
    int new_sch = students[i].get_scholarship() + c;
    students[i].set_scholarship(new_sch * !(new_sch < 0));
}

// R Экзамен
Exam::Exam()
{
    this->day = 0;
    this->hour = 0;
    this->year = 0;
}
Exam::~Exam() {}
ostream &operator<<(ostream &os, const Exam &exm)
{
    os << "Exam; " << exm.get_subject();
    return os;
}
void Exam::set_hour(int hr)
{
    this->hour = hr;
}
void Exam::set_day(int day)
{
    this->day = day;
}
void Exam::set_year(int yr)
{
    this->year = yr;
}
void Exam::set_subject(Subject sbj)
{
    this->subject = sbj;
}
int Exam::get_hour() const { return this->hour; }
int Exam::get_day() const { return this->day; }
int Exam::get_year() const { return this->year; }
Subject Exam::get_subject() const { return this->subject; }
vector<Student> Exam::change_marks(vector<Student> students)
{
    srand(time(nullptr));
    for (int i = 0; i < students.size(); i++)
    {
        double changer = double(rand() % 20 - 10) / 10;
        if (students[i].get_average_mark() + changer < 10 && students[i].get_average_mark() + changer > 0)
        {
            students[i].set_average_mark(students[i].get_average_mark() + changer);
        }
    }
    return students;
}

// R этаж
Floor::Floor()
{
    this->floor_height = 0;
}
Floor::~Floor() {}
ostream &operator<<(ostream &os, const Floor &flr)
{
    os << "Floor; Department name: " << flr.get_department()
       << "; Height: " << flr.floor_height;
    return os;
}
void Floor::set_department(Department dep)
{
    this->dep = dep;
}
void Floor::set_offices(vector<int> offices)
{
    this->offices = offices;
}
void Floor::set_floor_height(int fh)
{
    this->floor_height = fh;
}
Department Floor::get_department() const { return this->dep; }
vector<int> Floor::get_offices() const { return this->offices; }
int Floor::get_floor_height() const { return this->floor_height; }

// R Корпус
Building::Building()
{
    this->number = 0;
    this->street = "";
}
Building::~Building() {}
ostream &operator<<(ostream &os, const Building &bld)
{
    os << "Building; Number: " << bld.number << "; Street: " << bld.street;
    return os;
}
void Building::set_street(string strt)
{
    this->street = strt;
}
void Building::set_number(int nmr)
{
    this->number = nmr;
}
void Building::set_floors(vector<Floor> floors)
{
    this->floors = floors;
}
string Building::get_street() const { return this->street; }
int Building::get_number() const { return this->number; }
vector<Floor> Building::get_floors() const { return this->floors; }

// R Деканат
Dean_office::Dean_office() {}
Dean_office::~Dean_office() {}
ostream &operator<<(ostream &os, const Dean_office &deanof)
{
    os << "Dean office; " << deanof.get_dean();
    return os;
}
void Dean_office::set_dean(Dean dean)
{
    this->dean = dean;
}
Dean Dean_office::get_dean() const { return this->dean; }

// R Факультет
Faculty::Faculty() {}
Faculty::~Faculty() {}
ostream &operator<<(ostream &os, const Faculty &fclt)
{
    os << "Faculty; Name: " << fclt.name;
    return os;
}
void Faculty::set_dean_office(Dean_office deof)
{
    this->deanof = deof;
}
void Faculty::set_name(string nm)
{
    this->name = nm;
}
string Faculty::get_name() const { return this->name; }
Dean_office Faculty::get_dean_office() const { return this->deanof; }

int main()
{
    Student st1, st2;
    st1.set_gender("male");
    st1.set_name("Bob");
    st1.set_hours_skipped(2);
    st1.set_average_mark(8.7);
    st1.set_scholarship(33);

    st2.set_gender("male");
    st2.set_name("Dane");
    st2.set_hours_skipped(0);
    st2.set_average_mark(8.5);
    st2.set_scholarship(67);

    Employee em1;
    em1.set_gender("male");
    em1.set_name("Grub");
    em1.set_surname("Trub");
    em1.set_fathers_name("Togor");
    em1.set_phone_number(8012364732);
    em1.set_post("Curator");

    em1.work();

    vector<Student> students;
    students.push_back(st1);
    students.push_back(st2);
    Group gr1;
    gr1.set_curator(em1);
    gr1.set_list_of_students(students);
    gr1.set_number(322509);
    gr1.sort_students();
    show_list<Student>(gr1.get_list_of_students());

    Subject sbj1;
    sbj1.set_name("Math");
    sbj1.set_hours_to_study(108);

    Exam exm;
    exm.set_day(22);
    exm.set_hour(12);
    exm.set_year(2012);
    exm.set_subject(sbj1);

    gr1.set_list_of_students(exm.change_marks(gr1.get_list_of_students()));
    show_list<Student>(gr1.get_list_of_students());
    cout << gr1.get_list_of_students()[0].get_average_mark() << " " << gr1.get_list_of_students()[1].get_average_mark() << endl;

    Teacher tch1;
    tch1.set_name("A");
    tch1.set_surname("B");
    tch1.set_fathers_name("C");
    tch1.set_phone_number(80234234);
    tch1.set_gender("male");
    tch1.set_post("Teacher");
    tch1.set_subject(sbj1);
    tch1.set_salary(2);

    tch1.work();
    cout << tch1.get_salary() << endl;
}