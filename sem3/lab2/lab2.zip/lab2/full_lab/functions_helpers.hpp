#include <iostream>
#include <vector>
#include <limits>
#include <ctime>

template <typename Type>
// Test
Type check_key()
{
    Type number;

    while (1)
    {
        std::cin >> number;

        if (std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Incorrect input! Try again " << std::endl;
        }
        else
        {
            std::cin.clear();
            break;
        }
    }

    return number;
}

template <typename Type2>
void show_list(std::vector<Type2> list)
{
    for (int i = 0; i < list.size(); i++)
    {
        std::cout << i + 1 << ". " << list[i] << std::endl;
    }
}