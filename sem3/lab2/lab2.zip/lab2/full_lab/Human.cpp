#include <iostream>
#include <string>
#include "Human.hpp"
// R Человек
Human::Human()
{
    this->gender = "";
}
Human::~Human() {}
std::ostream &operator<<(std::ostream &os, const Human &hm)
{
    os << "Human; Gender: " << hm.gender;
    return os;
}
void Human::set_gender(std::string gender)
{
    this->gender = gender;
}
std::string Human::get_gender() const { return this->gender; }
void Human::tell_about_yourself() const
{
    std::cout << "I'm just a human; I'm " << this->gender << std::endl;
}
