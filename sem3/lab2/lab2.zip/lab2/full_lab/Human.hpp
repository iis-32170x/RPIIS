#pragma once
// Человек
#include <string>
#include <iostream>
class Human
{
private:
    std::string gender;

public:
    Human();
    virtual ~Human();

    virtual void tell_about_yourself() const;
    friend std::ostream &operator<<(std::ostream &os, const Human &man);

    void set_gender(std::string gender);
    std::string get_gender() const;
};