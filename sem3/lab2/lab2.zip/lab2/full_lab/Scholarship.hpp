#pragma once
#include <vector>
#include "Student.hpp"
// Стипендия
class Scholarship
{
private:
public:
    Scholarship();
    ~Scholarship();

    void set_scholarship(std::vector<Student> &students);
    void change_scholarship(std::vector<Student> &students);
};