#include "Scholarship.hpp"
#include "functions_helpers.hpp"
#include <vector>
#include "Student.hpp"
#include <iostream>
// R стипендия
Scholarship::Scholarship() {}
Scholarship::~Scholarship() {}
void Scholarship::set_scholarship(std::vector<Student> &students)
{
    for (int i = 0; i < students.size(); i++)
    {
        if (students[i].get_hours_skipped() > 9)
        {
            students[i].set_scholarship(0);
        }
    }
}
void Scholarship::change_scholarship(std::vector<Student> &students)
{
    show_list<Student>(students);
    std::cout << "Choose number: ";
    int i;
    std::cin >> i;
    i--;
    std::cout << "Enter change of scholrship (+/-): ";
    int c;
    std::cin >> c;
    int new_sch = students[i].get_scholarship() + c;
    students[i].set_scholarship(new_sch * !(new_sch < 0));
}