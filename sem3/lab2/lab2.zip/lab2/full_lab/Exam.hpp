#pragma once
#include "Subject.hpp"
#include "Student.hpp"
#include <iostream>
#include <vector>
// Экзамен
class Exam
{
private:
    int hour;
    int day;
    int year;
    Subject subject;

public:
    Exam();
    ~Exam();

    friend std::ostream &operator<<(std::ostream &os, const Exam &exam);

    void set_hour(int hour);
    void set_day(int day);
    void set_year(int year);
    void set_subject(Subject sbj);
    int get_hour() const;
    int get_day() const;
    int get_year() const;
    Subject get_subject() const;

    std::vector<Student> change_marks(std::vector<Student> students);
};