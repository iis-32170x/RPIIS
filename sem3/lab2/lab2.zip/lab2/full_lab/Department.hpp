#pragma once
#include <iostream>
#include <vector>
#include "Group.hpp"
#include "Employee.hpp"
#include "Exam.hpp"
#include "Subject.hpp"
#include <string>

class Department
{
private:
    std::string name;
    std::vector<Group> list_of_groups;
    std::vector<Employee> list_of_employees;
    std::vector<Subject> list_of_subjects;
    std::vector<Exam> list_of_exams;

public:
    Department();
    ~Department();

    friend std::ostream &operator<<(std::ostream &os, const Department &dep);

    void set_name(std::string name);
    void set_list_of_groups(std::vector<Group> list_of_groups);
    void set_list_of_employees(std::vector<Employee> list_of_employees);
    void set_list_of_subjects(std::vector<Subject> sbjcts);
    void set_list_of_exams(std::vector<Exam> exm);
    std::string get_name() const;
    std::vector<Group> get_list_of_groups() const;
    std::vector<Employee> get_list_of_employees() const;
    std::vector<Subject> get_list_of_subjects() const;
    std::vector<Exam> get_list_of_exams() const;

    void add_student(Student stdnt);
    void remove_student();
    void add_employee(Employee emp);
    void remove_employee();
    void add_subject(Subject sbj);
    void remove_subject();
    void add_exam(Exam exm);
    void remove_exam();
};