#include "Dean_office.hpp"
#include "Dean.hpp"
#include <iostream>
// R Деканат
Dean_office::Dean_office() {}
Dean_office::~Dean_office() {}
std::ostream &operator<<(std::ostream &os, const Dean_office &deanof)
{
    os << "Dean office; " << deanof.get_dean();
    return os;
}
void Dean_office::set_dean(Dean dean)
{
    this->dean = dean;
}
Dean Dean_office::get_dean() const { return this->dean; }
