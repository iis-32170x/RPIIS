#include <iostream>
#include <string>
#include "Employee.hpp"
#include <unistd.h>
// R Сотрудник
Employee::Employee()
{
    this->name = "";
    this->surname = "";
    this->fathers_name = "";
    this->phone_number = 0;
    this->post = "";
}
Employee::~Employee() {}
void Employee::tell_about_yourself() const
{
    std::cout << "I'm employee; " << *this << "; Phone: " << phone_number
              << "; Post: " << "Gender: " << this->get_gender() << std::endl;
}
std::ostream &operator<<(std::ostream &os, const Employee &employee)
{
    os << "Employee; FIO: " << employee.name << " " << employee.surname << " " << employee.fathers_name;
    return os;
}
void Employee::set_name(std::string name)
{
    this->name = name;
}
void Employee::set_surname(std::string surname)
{
    this->surname = surname;
}
void Employee::set_fathers_name(std::string fathers_name)
{
    this->fathers_name = fathers_name;
}
void Employee::set_phone_number(long int phone_number)
{
    this->phone_number = phone_number;
}
void Employee::set_post(std::string post)
{
    this->post = post;
}
std::string Employee::get_name() const { return this->name; }
std::string Employee::get_surname() const { return this->surname; }
std::string Employee::get_fathers_name() const { return this->fathers_name; }
long int Employee::get_phone_number() const { return this->phone_number; }
std::string Employee::get_post() const { return this->post; }
void Employee::work()
{
    std::cout << "This employee is doing some work" << std::endl;
    sleep(2);
}
