#include "Floor.hpp"
#include <iostream>
#include "Department.hpp"
#include <vector>
// R этаж
Floor::Floor()
{
    this->floor_height = 0;
}
Floor::~Floor() {}
std::ostream &operator<<(std::ostream &os, const Floor &flr)
{
    os << "Floor; Department name: " << flr.get_department()
       << "; Height: " << flr.floor_height;
    return os;
}
void Floor::set_department(Department dep)
{
    this->dep = dep;
}
void Floor::set_offices(std::vector<int> offices)
{
    this->offices = offices;
}
void Floor::set_floor_height(int fh)
{
    this->floor_height = fh;
}
Department Floor::get_department() const { return this->dep; }
std::vector<int> Floor::get_offices() const { return this->offices; }
int Floor::get_floor_height() const { return this->floor_height; }
