#include <UnitTest++/UnitTest++.h>
#include "Building.hpp"
#include "Dean_office.hpp"
#include "Dean.hpp"
#include "Department.hpp"
#include "Employee.hpp"
#include "Exam.hpp"
#include "Faculty.hpp"
#include "Floor.hpp"
#include "functions_helpers.hpp"
#include "Group.hpp"
#include "Human.hpp"
#include "Scholarship.hpp"
#include "Student.hpp"
#include "Subject.hpp"
#include "Teacher.hpp"

using namespace std;

TEST(Building_test)
{
    Building test;
    test.set_number(2);
    test.set_street("Trunk 96-7");

    CHECK_EQUAL(test.get_number(), 2);
    CHECK_EQUAL(test.get_street(), "Trunk 96-7");
}

TEST(Dean_office_test)
{
    Dean_office test;
    Dean dd;
    dd.set_name("Velikii");
    dd.set_phone_number(3242353);
    test.set_dean(dd);
    CHECK_EQUAL(test.get_dean().get_name(), "Velikii");
    CHECK_EQUAL(test.get_dean().get_phone_number(), 3242353);
}

TEST(Dean_test)
{
    Dean test;
    test.set_gender("helicopter");
    test.set_post("DEEE");
    CHECK_EQUAL(test.get_gender(), "helicopter");
    CHECK_EQUAL(test.get_post(), "DEEE");
    CHECK_EQUAL(test.get_phone_number(), 0);
}

TEST(Department_test)
{
    Department test;
    test.set_name("BDU");
    Student tt;
    tt.set_hours_skipped(2);
    vector<Student> gg;
    gg.push_back(tt);
    Group a;
    a.set_list_of_students(gg);
    vector<Group> aaa;
    aaa.push_back(a);
    test.set_list_of_groups(aaa);
    CHECK_EQUAL(test.get_name(), "BDU");
    CHECK_EQUAL(test.get_list_of_groups()[0].get_list_of_students()[0].get_hours_skipped(), 2);
}
TEST(Employee_test)
{
    Employee test;
    test.set_gender("HElicpter");
    test.set_name("Rick");
    test.set_phone_number(23234);
    test.work();
    CHECK_EQUAL(test.get_gender(), "HElicpter");
    CHECK_EQUAL(test.get_name(), "Rick");
    CHECK_EQUAL(test.get_phone_number(), 23234);
}
TEST(Exam_test)
{
    Exam test;
    test.set_day(23);
    test.set_hour(12);
    test.set_year(1990);
    CHECK_EQUAL(test.get_day(), 23);
    CHECK_EQUAL(test.get_hour(), 12);
    CHECK_EQUAL(test.get_year(), 1990);
}
TEST(Faculty_test)
{
    Faculty test;
    test.set_name("A");
    Dean_office aa;
    Dean m;
    m.set_post("cring");
    aa.set_dean(m);
    test.set_dean_office(aa);
    CHECK_EQUAL(test.get_dean_office().get_dean().get_post(), "cring");
    CHECK_EQUAL(test.get_name(), "A");
}
TEST(Floor_test)
{
    Floor test;
    test.set_floor_height(12);
    CHECK_EQUAL(test.get_floor_height(), 12);
    vector<int> tt;
    tt.push_back(2);
    tt.push_back(33);
    test.set_offices(tt);
    CHECK_EQUAL(test.get_offices()[1], 33);
}
TEST(Group_test)
{
    Group test;
    test.set_number(321);
    Employee tut;
    tut.set_name("b");
    tut.set_post("CURATOR OF 321");
    test.set_curator(tut);
    CHECK_EQUAL(test.get_number(), 321);
    CHECK_EQUAL(test.get_curator().get_name(), "b");
    CHECK_EQUAL(test.get_curator().get_post(), "CURATOR OF 321");
}
TEST(Human_test)
{
    Human yo;
    yo.set_gender("SHUU");
    yo.tell_about_yourself();
    CHECK_EQUAL(yo.get_gender(), "SHUU");
}
TEST(Scholarship_test)
{
    Scholarship test;
    Student a;
    a.set_hours_skipped(12);
    a.set_scholarship(120);
    vector<Student> tt;
    tt.push_back(a);
    test.set_scholarship(tt);
    CHECK_EQUAL(tt[0].get_scholarship(), 0);
}
TEST(Student_test)
{
    Student s;
    s.set_name("Bob");
    s.set_scholarship(120);
    s.set_average_mark(6.95);
    s.tell_about_yourself();
    CHECK_EQUAL(s.get_name(), "Bob");
    CHECK_EQUAL(s.get_scholarship(), 120);
    CHECK_EQUAL(s.get_average_mark(), 6.95);
    s.study();
    CHECK_EQUAL(s.get_average_mark(), 7);
}
TEST(Subject_test)
{
    Subject t;
    t.set_hours_to_study(108);
    t.set_name("MAth");
    CHECK_EQUAL(t.get_hours_to_sudy(), 108);
    CHECK_EQUAL(t.get_name(), "MAth");
}
TEST(Teacher_test)
{
    Teacher t;
    t.set_name("B");
    t.set_salary(300);
    t.tell_about_yourself();
    CHECK_EQUAL(t.get_name(), "B");
    CHECK_EQUAL(t.get_salary(), 300);
    t.work();
    CHECK_EQUAL(t.get_salary(), 427);
}
int main(int, char **)
{
    return UnitTest::RunAllTests();
}