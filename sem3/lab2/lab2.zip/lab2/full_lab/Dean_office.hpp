#pragma once
#include "Dean.hpp"
#include <iostream>
// Деканат
class Dean_office
{
private:
    Dean dean;

public:
    Dean_office();
    ~Dean_office();

    friend std::ostream &operator<<(std::ostream &os, const Dean_office &deanof);

    void set_dean(Dean dean);
    Dean get_dean() const;
};