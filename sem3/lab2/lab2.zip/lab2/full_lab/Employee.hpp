#pragma once
#include "Human.hpp"
#include <iostream>
#include <string>
// Сотрудник
class Employee : public Human
{
private:
    std::string name;
    std::string surname;
    std::string fathers_name;
    long int phone_number;
    std::string post;

public:
    Employee();
    ~Employee();

    virtual void tell_about_yourself() const override;
    friend std::ostream &operator<<(std::ostream &os, const Employee &employee);

    void set_name(std::string name);
    void set_surname(std::string name);
    void set_fathers_name(std::string fathers_name);
    void set_phone_number(long int phone_number);
    void set_post(std::string post);
    std::string get_name() const;
    std::string get_surname() const;
    std::string get_fathers_name() const;
    long int get_phone_number() const;
    std::string get_post() const;

    virtual void work();
};