#include "Building.hpp"
#include <iostream>
#include <vector>
#include <string>
#include "Floor.hpp"
// R Корпус
Building::Building()
{
    this->number = 0;
    this->street = "";
}
Building::~Building() {}
std::ostream &operator<<(std::ostream &os, const Building &bld)
{
    os << "Building; Number: " << bld.number << "; Street: " << bld.street;
    return os;
}
void Building::set_street(std::string strt)
{
    this->street = strt;
}
void Building::set_number(int nmr)
{
    this->number = nmr;
}
void Building::set_floors(std::vector<Floor> floors)
{
    this->floors = floors;
}
std::string Building::get_street() const { return this->street; }
int Building::get_number() const { return this->number; }
std::vector<Floor> Building::get_floors() const { return this->floors; }
