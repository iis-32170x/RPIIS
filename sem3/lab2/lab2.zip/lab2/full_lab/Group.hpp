#pragma once
#include "Employee.hpp"
#include "Student.hpp"
#include <iostream>
#include <vector>
// Группа
class Group
{
private:
    int number;
    Employee curator;
    std::vector<Student> list_of_students;

public:
    Group();
    ~Group();

    friend std::ostream &operator<<(std::ostream &os, const Group &grp);

    void set_number(int number);
    void set_curator(Employee curator);
    void set_list_of_students(std::vector<Student> list_of_students);

    int get_number() const;
    Employee get_curator() const;
    std::vector<Student> get_list_of_students() const;

    void sort_students();
};