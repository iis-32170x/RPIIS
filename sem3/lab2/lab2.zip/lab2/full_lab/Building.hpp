#pragma once
#include <iostream>
#include <string>
#include "Floor.hpp"
#include <vector>
// Корпус
class Building
{
private:
    std::string street;
    int number;
    std::vector<Floor> floors;

public:
    Building();
    ~Building();

    friend std::ostream &operator<<(std::ostream &os, const Building &bld);

    void set_street(std::string strt);
    void set_number(int nmr);
    void set_floors(std::vector<Floor> floors);
    std::string get_street() const;
    int get_number() const;
    std::vector<Floor> get_floors() const;
};