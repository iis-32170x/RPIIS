#pragma once
#include "Dean_office.hpp"
#include <string>
#include <iostream>
// Факультет
class Faculty
{
private:
    Dean_office deanof;
    std::string name;

public:
    Faculty();
    ~Faculty();

    friend std::ostream &operator<<(std::ostream &os, const Faculty &name);

    void set_dean_office(Dean_office deanof);
    void set_name(std::string name);
    std::string get_name() const;
    Dean_office get_dean_office() const;
};