#pragma once
#include <iostream>
#include <string>
#include "Human.hpp"

class Student : public Human
{
private:
    std::string name;
    int hours_skipped;
    int scholarship;
    double average_mark;

public:
    Student();
    ~Student();

    virtual void tell_about_yourself() const override;
    friend std::ostream &operator<<(std::ostream &os, const Student &student);

    void set_name(std::string name);
    void set_hours_skipped(int hours_skipped);
    void set_scholarship(int salary);
    void set_average_mark(double mark);
    std::string get_name() const;
    int get_hours_skipped() const;
    int get_scholarship() const;
    double get_average_mark() const;

    virtual void study();
};