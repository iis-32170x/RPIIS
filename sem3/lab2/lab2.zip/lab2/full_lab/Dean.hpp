#pragma once
#include "Employee.hpp"
#include "Building.hpp"
#include "Human.hpp"
#include <iostream>
// Декан
class Dean : public Employee
{
private:
    Building building;

public:
    Dean();
    ~Dean();

    friend std::ostream &operator<<(std::ostream &os, const Dean &dn);
    void who_are_you(const Human *human) const;

    void set_bld(Building building);
    Building get_bld() const;
};