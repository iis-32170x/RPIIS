#include <iostream>
#include <string>
#include "Subject.hpp"
// R Дисциплина
Subject::Subject()
{
    this->hours_to_study = 0;
    this->name = "";
}
Subject::~Subject() {}
std::ostream &operator<<(std::ostream &os, const Subject &sbj)
{
    os << "Subject; Name: " << sbj.name;
    return os;
}
void Subject::set_hours_to_study(int hours_to_study)
{
    this->hours_to_study = hours_to_study;
}
void Subject::set_name(std::string name)
{
    this->name = name;
}
int Subject::get_hours_to_sudy() const { return this->hours_to_study; }
std::string Subject::get_name() const { return this->name; }
