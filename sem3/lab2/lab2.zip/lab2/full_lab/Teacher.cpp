#include "Teacher.hpp"
#include <iostream>
#include "Student.hpp"
#include "Subject.hpp"
#include "functions_helpers.hpp"
#include <unistd.h>
#include <vector>
// R Учитель
Teacher::Teacher()
{
    this->salary = 0;
}
Teacher::~Teacher() {}
std::ostream &operator<<(std::ostream &os, const Teacher &tchr)
{
    os << "Teacher; Name: " << tchr.get_name();
    return os;
}
void Teacher::tell_about_yourself() const
{
    std::cout << "I'm teacher; " << *this << "; Salary: " << this->salary << std::endl;
}
void Teacher::set_salary(int salary)
{
    this->salary = salary;
}
void Teacher::set_subject(Subject subject)
{
    this->subject = subject;
}
int Teacher::get_salary() const { return this->salary; }
Subject Teacher::get_subject() const { return this->subject; }
void Teacher::add_skipped_hours(std::vector<Student> &students)
{
    show_list<Student>(students);
    std::cout << "Choose student's number: ";
    int i;
    std::cin >> i;
    i--;
    students[i].set_hours_skipped(students[i].get_hours_skipped() + 2);
}
void Teacher::work()
{
    sleep(2);
    this->salary += 127;
}
