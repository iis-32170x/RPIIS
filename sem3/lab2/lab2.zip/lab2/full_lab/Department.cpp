#include "Department.hpp"
#include <iostream>
#include <vector>
#include "Group.hpp"
#include "Employee.hpp"
#include "Exam.hpp"
#include "Subject.hpp"
#include <string>
#include "functions_helpers.hpp"
// R Кафедра
Department::Department()
{
    this->name = "";
}
Department::~Department() {}
std::ostream &operator<<(std::ostream &os, const Department &dep)
{
    os << "Department; Name: " << dep.name;
    return os;
}
void Department::set_name(std::string name)
{
    this->name = name;
}
void Department::set_list_of_employees(std::vector<Employee> list_of_employees)
{
    this->list_of_employees = list_of_employees;
}
void Department::set_list_of_groups(std::vector<Group> list_of_groups)
{
    this->list_of_groups = list_of_groups;
}
void Department::set_list_of_subjects(std::vector<Subject> sbjcts)
{
    this->list_of_subjects = sbjcts;
}
void Department::set_list_of_exams(std::vector<Exam> exms)
{
    this->list_of_exams = exms;
}
std::string Department::get_name() const { return this->name; }
std::vector<Employee> Department::get_list_of_employees() const { return this->list_of_employees; }
std::vector<Group> Department::get_list_of_groups() const { return this->list_of_groups; }
std::vector<Subject> Department::get_list_of_subjects() const { return this->list_of_subjects; }
std::vector<Exam> Department::get_list_of_exams() const { return this->list_of_exams; }
void Department::add_student(Student stdnt)
{
    show_list<Group>(list_of_groups);
    int i;
    std::cout << "Choose group position: ";
    do
    {
        i = check_key<int>();
    } while (i < 1 || i > list_of_groups.size());
    i--;
    std::vector<Student> temp = list_of_groups[i].get_list_of_students();
    temp.push_back(stdnt);
    list_of_groups[i].set_list_of_students(temp);
}
void Department::remove_student()
{
    show_list<Group>(list_of_groups);
    int i;
    std::cout << "Choose group position: ";
    do
    {
        i = check_key<int>();
    } while (i < 1 || i > list_of_groups.size());
    i--;
    std::vector<Student> temp = list_of_groups[i].get_list_of_students();
    show_list<Student>(temp);
    int i2;
    std::cout << "Choose student position: ";
    do
    {
        i2 = check_key<int>();
    } while (i2 < 1 || i2 > temp.size());
    i2--;
    temp.erase(next(temp.begin(), i2));
    list_of_groups[i].set_list_of_students(temp);
}
void Department::add_employee(Employee emp)
{
    list_of_employees.push_back(emp);
}
void Department::remove_employee()
{
    show_list<Employee>(list_of_employees);
    int i2;
    std::cout << "Choose employee position: ";
    do
    {
        i2 = check_key<int>();
    } while (i2 < 1 || i2 > list_of_employees.size());
    i2--;
    list_of_employees.erase(next(list_of_employees.begin(), i2));
}
void Department::add_subject(Subject sbj)
{
    list_of_subjects.push_back(sbj);
}
void Department::remove_subject()
{
    show_list<Subject>(list_of_subjects);
    int i2;
    std::cout << "Choose subject position: ";
    do
    {
        i2 = check_key<int>();
    } while (i2 < 1 || i2 > list_of_subjects.size());
    i2--;
    list_of_subjects.erase(next(list_of_subjects.begin(), i2));
}
void Department::add_exam(Exam exm)
{
    list_of_exams.push_back(exm);
}
void Department::remove_exam()
{
    show_list<Exam>(list_of_exams);
    int i2;
    std::cout << "Choose exam position: ";
    do
    {
        i2 = check_key<int>();
    } while (i2 < 1 || i2 > list_of_exams.size());
    i2--;
    list_of_exams.erase(next(list_of_exams.begin(), i2));
}
