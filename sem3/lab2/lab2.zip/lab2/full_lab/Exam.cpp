#include <iostream>
#include <vector>
#include "Exam.hpp"
#include "Student.hpp"
#include "Subject.hpp"
// R Экзамен
Exam::Exam()
{
    this->day = 0;
    this->hour = 0;
    this->year = 0;
}
Exam::~Exam() {}
std::ostream &operator<<(std::ostream &os, const Exam &exm)
{
    os << "Exam; " << exm.get_subject();
    return os;
}
void Exam::set_hour(int hr)
{
    this->hour = hr;
}
void Exam::set_day(int day)
{
    this->day = day;
}
void Exam::set_year(int yr)
{
    this->year = yr;
}
void Exam::set_subject(Subject sbj)
{
    this->subject = sbj;
}
int Exam::get_hour() const { return this->hour; }
int Exam::get_day() const { return this->day; }
int Exam::get_year() const { return this->year; }
Subject Exam::get_subject() const { return this->subject; }
std::vector<Student> Exam::change_marks(std::vector<Student> students)
{
    srand(time(nullptr));
    for (int i = 0; i < students.size(); i++)
    {
        double changer = double(rand() % 20 - 10) / 10;
        if (students[i].get_average_mark() + changer < 10 && students[i].get_average_mark() + changer > 0)
        {
            students[i].set_average_mark(students[i].get_average_mark() + changer);
        }
    }
    return students;
}