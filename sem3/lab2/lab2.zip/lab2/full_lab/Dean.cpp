#include "Dean.hpp"
#include "Human.hpp"
#include <iostream>
// R Декан
Dean::Dean()
{
}
Dean::~Dean() {}
std::ostream &operator<<(std::ostream &os, const Dean &dean)
{
    os << "Dean; Name: " << dean.get_name();
    return os;
}
void Dean::who_are_you(const Human *human) const
{
    human->tell_about_yourself();
}