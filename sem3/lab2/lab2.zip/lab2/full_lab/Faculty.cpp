#include "Faculty.hpp"
#include "Dean_office.hpp"
#include <string>
#include <iostream>
// R Факультет
Faculty::Faculty() {}
Faculty::~Faculty() {}
std::ostream &operator<<(std::ostream &os, const Faculty &fclt)
{
    os << "Faculty; Name: " << fclt.name;
    return os;
}
void Faculty::set_dean_office(Dean_office deof)
{
    this->deanof = deof;
}
void Faculty::set_name(std::string nm)
{
    this->name = nm;
}
std::string Faculty::get_name() const { return this->name; }
Dean_office Faculty::get_dean_office() const { return this->deanof; }
