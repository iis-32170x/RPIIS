#include <iostream>
#include "functions_helpers.hpp"
#include "Human.hpp"
#include "Employee.hpp"
#include "Student.hpp"
int main()
{
    Human test;
    test.set_gender("AHISH");
    std::cout << test.get_gender() << "\n";
    Employee tt;
    tt.work();
}