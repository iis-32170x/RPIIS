#pragma once
#include <iostream>
#include <string>
// Дисциплина
class Subject
{
private:
    std::string name;
    int hours_to_study;

public:
    Subject();
    ~Subject();

    friend std::ostream &operator<<(std::ostream &os, const Subject &sbj);

    void set_name(std::string name);
    void set_hours_to_study(int hours_to_study);
    std::string get_name() const;
    int get_hours_to_sudy() const;
};