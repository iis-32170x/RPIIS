#pragma once
#include <iostream>
#include <vector>
#include "Department.hpp"
// Этаж
class Floor
{
private:
    Department dep;
    std::vector<int> offices;
    int floor_height;

public:
    Floor();
    ~Floor();

    friend std::ostream &operator<<(std::ostream &os, const Floor &fl);

    void set_department(Department dep);
    void set_offices(std::vector<int> offcs);
    void set_floor_height(int height);
    Department get_department() const;
    std::vector<int> get_offices() const;
    int get_floor_height() const;
};