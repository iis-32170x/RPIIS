#pragma once
#include "Employee.hpp"
#include <iostream>
#include "Subject.hpp"
#include <vector>
#include "Student.hpp"
// Учитель
class Teacher : public Employee
{
private:
    int salary;
    Subject subject;

public:
    Teacher();
    ~Teacher();

    friend std::ostream &operator<<(std::ostream &os, const Teacher &tch);
    virtual void tell_about_yourself() const override;

    void set_salary(int salary);
    int get_salary() const;
    void set_subject(Subject subject);
    Subject get_subject() const;

    void add_skipped_hours(std::vector<Student> &students);

    virtual void work() override;
};