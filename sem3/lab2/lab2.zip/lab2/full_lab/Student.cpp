#include <iostream>
#include <string>
#include "Student.hpp"

// R Студент
Student::Student()
{
    this->name = "";
    this->hours_skipped = 0;
    this->scholarship = 0;
    this->average_mark = 0;
}
Student::~Student() {}
void Student::tell_about_yourself() const
{
    std::cout << "I'm student; " << *this << "; Skipped hours: " << hours_skipped
              << "; Scholarship: " << scholarship << "; Average mark: " << average_mark << std::endl;
}
std::ostream &operator<<(std::ostream &os, const Student &student)
{
    os << "Student; Name: " << student.name;
    return os;
}
void Student::set_name(std::string name)
{
    this->name = name;
}
void Student::set_hours_skipped(int hours_skipped)
{
    this->hours_skipped = hours_skipped;
}
void Student::set_scholarship(int salary)
{
    this->scholarship = salary;
}
void Student::set_average_mark(double mark)
{
    this->average_mark = mark;
}
std::string Student::get_name() const { return this->name; }
int Student::get_hours_skipped() const { return this->hours_skipped; }
int Student::get_scholarship() const { return this->scholarship; }
double Student::get_average_mark() const { return this->average_mark; }
void Student::study()
{
    if (average_mark + 0.05 < 10)
    {
        std::cout << "Student is learning" << std::endl;
        average_mark += 0.05;
    }
    else
    {
        std::cout << "Student has best mark" << std::endl;
    }
}