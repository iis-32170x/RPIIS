#include <iostream>
#include <vector>
#include "Group.hpp"
#include "Student.hpp"
#include "Employee.hpp"
#include "functions_helpers.hpp"
// R Группа
Group::Group()
{
    this->number = 0;
}
Group::~Group() {}
std::ostream &operator<<(std::ostream &os, const Group &grp)
{
    os << "Group; Number: " << grp.number;
    return os;
}
void Group::set_number(int number)
{
    this->number = number;
}
void Group::set_curator(Employee curator)
{
    this->curator = curator;
}
void Group::set_list_of_students(std::vector<Student> list_of_students)
{
    this->list_of_students = list_of_students;
}
int Group::get_number() const { return this->number; }
Employee Group::get_curator() const { return this->curator; }
std::vector<Student> Group::get_list_of_students() const { return this->list_of_students; }
void Group::sort_students()
{
    std::cout << "1 - sort by name; 2 - sort by average mark: ";
    int i;
    do
    {
        i = check_key<int>();
    } while (i < 1 || i > 2);
    if (i == 1)
    {
        Student k;
        for (int i = 0; i < list_of_students.size() - 1; i++)
        {
            for (int j = 1; i < list_of_students.size(); i++)
            {
                if (list_of_students[i].get_name() > list_of_students[j].get_name())
                {
                    k = list_of_students[i];
                    list_of_students[i] = list_of_students[j];
                    list_of_students[j] = k;
                }
            }
        }
    }
    else
    {
        Student k;
        for (int i = 0; i < list_of_students.size() - 1; i++)
        {
            for (int j = 1; i < list_of_students.size(); i++)
            {
                if (list_of_students[i].get_average_mark() > list_of_students[j].get_average_mark())
                {
                    k = list_of_students[i];
                    list_of_students[i] = list_of_students[j];
                    list_of_students[j] = k;
                }
            }
        }
    }
}