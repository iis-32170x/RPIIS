#include <iostream>
#include <cassert>
#include <limits>

/**
 * @brief Проверка ввода с клавиатуры.
 * 
 * Функция запрашивает ввод целого числа от пользователя. В случае неверного ввода
 * повторяет запрос, пока не будет введено корректное значение.
 * 
 * @return Введенное пользователем целое число.
 */
int check_key()
{
    int number;

    while(1)
    {   
        std::cin >> number;

        if(std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Incorrect input! Try again " << std::endl;
        }
        else
        {
            std::cin.clear();
            break;
        }
    }
    
    return number;
}

/**
 * @brief Класс, представляющий дробь.
 * 
 * Класс предназначен для выполнения различных операций с дробями, таких как 
 * сложение, вычитание, умножение, деление и сравнение.
 */
class decimal
{
private:
    int numerator;   ///< Числитель дроби
    int denominator; ///< Знаменатель дроби

    /**
     * @brief Сокращение дроби.
     * 
     * Использует алгоритм Евклида для нахождения наибольшего общего делителя (НОД) 
     * числителя и знаменателя, затем делит их на НОД.
     */
    void reduct_decimal()
    {
        int a = abs(numerator);
        int b = abs(denominator);

        while(a && b)
        {
            if (a == 1 || b == 1)
            {
                a = 1;
                b = 0;
                break;
            }
            
            if(a > b)
            {
                a = a % b;
            }
            else
            {
                b = b % a;
            }
        }

        numerator /= (a + b);
        denominator /= (a + b);

        if (denominator < 0)
        {
            denominator = -denominator;
            numerator = -numerator;
        }
    }

public:
    /**
     * @brief Конструктор дроби.
     * 
     * @param m_numerator Числитель.
     * @param m_denominator Знаменатель.
     */
    decimal(int m_numerator = 0, int m_denominator = 1)
    {
        numerator = m_numerator;
        denominator = m_denominator;
    }

    /**
     * @brief Конструктор копирования.
     * 
     * Копирует дробь, добавляя 3 к числителю.
     * 
     * @param some_decimal Другая дробь для копирования.
     */
    decimal(const decimal &some_decimal)
    {
        numerator = some_decimal.numerator + 3;
        denominator = some_decimal.denominator;
        this->reduct_decimal();
    }

    /**
     * @brief Деструктор дроби.
     */
    ~decimal()
    {
    }

    /**
     * @brief Получает числитель дроби.
     * 
     * @return Числитель.
     */
    int get_numerator() { return numerator; }

    /**
     * @brief Получает знаменатель дроби.
     * 
     * @return Знаменатель.
     */
    int get_denominator() { return denominator; }

    /**
     * @brief Ввод целой части, числителя и знаменателя.
     * 
     * Запрашивает ввод от пользователя для целой части, числителя и знаменателя дроби.
     */
    void input_num_denom_main()
    {
        int whole_part;
        
        std::cout << "Input whole part: ";
        whole_part = check_key();

        std::cout << "Input numerator: ";
        numerator = check_key(); 
        do
        { 
            std::cout << "Input denominator: ";
            denominator = check_key();
        } while (denominator <= 0 && std::cout << "Denominator must be > 0, retry" << std::endl);

        if(numerator < 0) {whole_part = -whole_part;}
        else if(whole_part < 0) {numerator = -numerator;}
        
        if (numerator == denominator)
        {
            numerator = whole_part + 1; 
            denominator = 1;
        }
        else if (numerator != 0)
        {
            numerator = whole_part * denominator + numerator;
        }
        else if (numerator == 0)
        {
            numerator = 0;
            denominator = 1;
        }

        this->reduct_decimal();
    }

    /**
     * @brief Оператор присваивания.
     * 
     * @param right_operand Дробь, которая будет присвоена.
     * @return Дробь после присваивания.
     */
    decimal operator=(const decimal& right_operand)
    {
        this->numerator = right_operand.numerator;
        this->denominator = right_operand.denominator;
        return *this;
    }

    // Операторы для сложения, вычитания, умножения, деления и сравнения дробей...

    /**
     * @brief Преобразование дроби в double.
     * 
     * @return Значение дроби в виде числа с плавающей точкой.
     */
    double to_double()
    {
        return double(numerator) / denominator;
    }

    /**
     * @brief Вывод дроби в стандартный поток.
     */
    void show()
    {
        if (numerator != 0)
        {
            std::cout << numerator << "/" << denominator;
        }
        else
        {
            std::cout << numerator;
        }
    }
};

/**
 * @brief Главная функция.
 * 
 * Основная функция, демонстрирующая функционал класса `decimal`.
 */
int main()
{
    decimal drob1, drob2;

    int switcher = 1, f_operations = 0;

    double tr_double;

    while(switcher)
    {
        std::cout << "Your operands: "; drob1.show(); std::cout << ", "; drob2.show(); std::cout << ", " << f_operations; std::cout << std::endl;
        std::cout << "1 - Input operands" << std::endl;
        std::cout << "2 - Perform operations" << std::endl;
        std::cout << "0 - Quit" << std::endl;

        switcher = check_key();

        switch(switcher)
        {
            case(1):
            {
                std::cout << "Input first decimal operand" << std::endl;
                drob1.input_num_denom_main();

                std::cout << "Input second decimal operand" << std::endl;
                drob2.input_num_denom_main();

                std::cout << "Input third integer operand" << std::endl;
                f_operations = check_key();

                break;
            }
            case(2):
            {
                decimal temp_drob1 = drob1;

                std::cout << "Operations with decimals:" << std::endl;
                drob1.show(); std::cout << " + "; drob2.show(); std::cout << " = "; (drob1 + drob2).show(); std::cout << std::endl;
                // Остальные операции...

                std::cout << "To double:" << std::endl;
                tr_double = drob1.to_double();
                drob1.show(); std::cout << " => " << tr_double << std::endl;

                tr_double = drob2.to_double();
                drob2.show(); std::cout << " => " << tr_double << std::endl;
                break;
            }
            case(0):
            {
                break;
            }
            default:
            {
                break;
            }
        }
    }
}

