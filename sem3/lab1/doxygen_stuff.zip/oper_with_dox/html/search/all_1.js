var searchData=
[
  ['get_5fdenominator_0',['get_denominator',['../classdecimal.html#a098ef38249a9effc9bb41f6ddb2e3be0',1,'decimal']]],
  ['get_5fnumerator_1',['get_numerator',['../classdecimal.html#a4629e7e335a11b98e8d954e0651536b1',1,'decimal']]]
];
