var searchData=
[
  ['decimal_0',['decimal',['../classdecimal.html',1,'']]]
];
