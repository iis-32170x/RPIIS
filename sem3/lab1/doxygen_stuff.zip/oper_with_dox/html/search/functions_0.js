var searchData=
[
  ['decimal_0',['decimal',['../classdecimal.html#a512917fd7eebc68d008f1844cf0f4950',1,'decimal::decimal(int m_numerator=0, int m_denominator=1)'],['../classdecimal.html#aba419b029bbba3e55f69283b5538d415',1,'decimal::decimal(const decimal &amp;some_decimal)']]]
];
