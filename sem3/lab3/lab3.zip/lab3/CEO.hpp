#pragma once
#include "employee.hpp"
#include "bank.hpp"
class CEO : public Employee
{
private:
    int IQ = 0;
    Bank *bank = nullptr;

public:
    CEO();
    ~CEO();

    void set_iq(int iq);
    void set_bank(Bank *bank);

    int get_iq() const;
    Bank *get_bank() const;

    void adjust_economy();
    virtual void work() override;
};