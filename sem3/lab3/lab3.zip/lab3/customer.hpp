#pragma once
#include "human.hpp"
#include "card.hpp"
#include "ATM.hpp"
#include <vector>
#include <iostream>
class Customer : public Human
{
protected:
    std::vector<Card *> cards;

public:
    Customer();
    ~Customer();

    void set_cards(std::vector<Card *> cards);

    std::vector<Card *> get_cards() const;

    void add_card(Card *card);
    void remove_card();
    Card *give_card();
};