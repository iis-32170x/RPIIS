#include "debit_card.hpp"
#include <iostream>
Debit_card::Debit_card() {}
Debit_card::~Debit_card() {}

double Debit_card::withdrawal(double sum)
{
    if (sum == 0)
    {
        std::cout << "Input sum: ";
        std::cin >> sum;
    }
    if (this->balance - sum < 0)
    {
        std::cout << "Not enough cash\n";
    }
    else
    {
        this->balance -= sum;
    }
    return sum;
}

void Debit_card::refill_balance(double sum)
{
    this->balance += sum;
}