#include "employee.hpp"
#include "bank.hpp"
#include "CEO.hpp"

CEO::CEO() {}
CEO::~CEO() {}

void CEO::set_iq(int iq)
{
    this->IQ = iq;
}
void CEO::set_bank(Bank *bank)
{
    this->bank = bank;
}

int CEO::get_iq() const { return this->IQ; }
Bank *CEO::get_bank() const { return this->bank; }

void CEO::adjust_economy()
{
    double coef = this->IQ / 100;
    double n_inf = this->bank->get_inflation() / coef;
    this->bank->set_inflation(n_inf);
    this->bank->set_key_rate(n_inf + 0.01);
}

void CEO::work()
{
    this->IQ += 2;
    this->salary += 4;
}