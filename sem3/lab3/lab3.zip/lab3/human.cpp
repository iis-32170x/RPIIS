#include "human.hpp"
#include <string>
#include <iostream>
Human::Human() {}
Human::~Human() {}

void Human::set_age(int age)
{
    if (age < 0 || age > 150)
    {
        std::cout << "Bad age range\n";
    }
    else
    {
        this->age = age;
    }
}
void Human::set_name(std::string name)
{
    this->name = name;
}

int Human::get_age() const { return this->age; }
std::string Human::get_name() const { return this->name; }