#pragma once
#include <string>
#include <iostream>
class Human
{
protected:
    int age = 0;
    std::string name = "";

public:
    Human();
    ~Human();

    void set_age(int age);
    void set_name(std::string name);

    int get_age() const;
    std::string get_name() const;
};