#pragma once
#include "department.hpp"
#include "customer.hpp"
#include <iostream>
#include "card.hpp"

class Deposit_department : public Department
{
private:
    double rate = 0;

public:
    Deposit_department();
    ~Deposit_department();

    void set_rate(double rate);

    double get_rate() const;

    virtual void main_function(Customer *customer) override;
};