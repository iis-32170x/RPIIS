#include "exchange_dep.hpp"
#include "department.hpp"
#include "customer.hpp"
#include <iostream>
#include "card.hpp"

Exchange_department::Exchange_department() {}
Exchange_department::~Exchange_department() {}

void Exchange_department::main_function(Customer *cus)
{
    std::cout << "Choose two different cards (1 - sender, 2 - reciever): ";
    Card *c1 = cus->give_card();
    Card *c2 = nullptr;
    do
    {
        c2 = cus->give_card();
    } while (c1 == c2);

    double sum;
    std::cout << "Input sum to exchange between cards: ";
    do
    {
        std::cin >> sum;
    } while (sum < 0);

    c2->refill_balance(c1->withdrawal(sum));
}