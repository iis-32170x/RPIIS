
#include "department.hpp"
#include "customer.hpp"
#include "deposit_dep.hpp"
#include <iostream>
#include <unistd.h>
#include "card.hpp"

Deposit_department::Deposit_department() {}
Deposit_department::~Deposit_department() {}

void Deposit_department::set_rate(double rate)
{
    if (rate > 100 || rate < 0)
    {
        std::cout << "Incorrect value\n";
    }
    else
    {
        this->rate = rate;
    }
}

double Deposit_department::get_rate() const { return this->rate; }

void Deposit_department::main_function(Customer *person)
{
    int days;
    std::cout << "Input amount of days (deposit): ";

    do
    {
        std::cin >> days;
    } while (days < 0);

    Card *c = person->give_card();
    double cash = c->get_balance();

    usleep(1000000 * (1 / (double(employees.size()) * 10)));
    cash = cash + (cash * this->rate * (this->effeciency + 1)) * double(days) / 30;

    c->set_balance(cash);
}