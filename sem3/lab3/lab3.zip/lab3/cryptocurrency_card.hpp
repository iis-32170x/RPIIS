#pragma once
#include "card.hpp"
#include <iostream>
class Cryptocurrency_card : public Card
{
private:
    double bitcoin = 0;
    double course = 0;
    int commission = 0;

public:
    Cryptocurrency_card();
    ~Cryptocurrency_card();

    void set_bitcoin(double bitcoin);
    void set_commission(int cmsn);
    void set_course(double course);

    double get_bitcoin() const;
    int get_commission() const;
    double get_course() const;

    virtual double withdrawal(double sum = 0) override;
    virtual void refill_balance(double sum) override;
};