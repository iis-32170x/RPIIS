#include "human.hpp"
#include "customer.hpp"
#include "employee.hpp"
#include <iostream>

Employee::Employee() {}
Employee::~Employee() {}

void Employee::set_salary(double salary)
{
    this->salary = salary;
}

double Employee::get_salary() const { return this->salary; }
