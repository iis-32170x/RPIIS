#pragma once
#include <vector>
#include <string>
#include "employee.hpp"
#include "customer.hpp"
class Department
{
protected:
    double effeciency = 0;
    std::vector<Employee *> employees;
    std::string name = "";

public:
    Department();
    virtual ~Department();

    void set_effeciency(double eff);
    void set_employees(std::vector<Employee *> employees);
    void set_name(std::string name);

    double get_effeciency() const;
    std::vector<Employee *> get_employees() const;
    std::string get_name() const;

    virtual void main_function(Customer *customer) = 0;
};