#pragma once
#include "card.hpp"
#include <iostream>
class ATM
{
private:
public:
    ATM();
    ~ATM();

    void operations(Card *card) const;
};