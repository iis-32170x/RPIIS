
#include "employee.hpp"
#include "department.hpp"
#include "manager.hpp"

Manager::Manager() {}
Manager::~Manager() {}

void Manager::set_department(Department *dep)
{
    this->department = dep;
}

Department *Manager::get_department() const { return this->department; }

void Manager::work()
{
    if (this->department->get_effeciency() < 100)
    {
        this->department->set_effeciency(this->department->get_effeciency() * 1.05);
    }
}