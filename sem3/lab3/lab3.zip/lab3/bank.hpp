#pragma once
#include <string>
#include <vector>
#include "ATM.hpp"
#include "manager.hpp"

class Bank
{
private:
    std::string name = "";
    std::vector<Manager *> managers;
    std::vector<ATM *> atms;
    double key_rate = 0;
    double inflation = 0;

public:
    Bank();
    ~Bank();

    void set_name(std::string name);
    void set_managers(std::vector<Manager *> managers);
    void set_atms(std::vector<ATM *> atms);
    void set_key_rate(double kr);
    void set_inflation(double inflation);

    std::string get_name() const;
    std::vector<Manager *> get_managers() const;
    std::vector<ATM *> get_atms() const;
    double get_key_rate() const;
    double get_inflation() const;
};