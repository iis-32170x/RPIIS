#pragma once
#include "employee.hpp"
#include "department.hpp"
class Manager : public Employee
{
private:
    Department *department = nullptr;

public:
    Manager();
    ~Manager();

    void set_department(Department *department);

    Department *get_department() const;

    virtual void work() override;
};