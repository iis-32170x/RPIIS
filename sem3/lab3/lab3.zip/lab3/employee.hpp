#pragma once
#include "human.hpp"
#include "customer.hpp"
#include <iostream>
class Employee : public Customer
{
protected:
    double salary = 0;

public:
    Employee();
    virtual ~Employee();

    void set_salary(double salary);

    double get_salary() const;

    virtual void work() = 0;
};