#pragma once
#include "card.hpp"
#include <iostream>
class Credit_card : public Card
{
private:
    double limit = 0;
    int cashback = 0;

public:
    Credit_card();
    ~Credit_card();

    void set_limit(double limit);
    void set_cashback(int cashback);

    double get_limit() const;
    int get_cashback() const;

    virtual double withdrawal(double sum = 0) override;
    virtual void refill_balance(double sum) override;
};