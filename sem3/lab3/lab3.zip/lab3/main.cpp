#include "ATM.hpp"
#include "customer.hpp"
#include "card.hpp"
#include "credit_card.hpp"
#include "cryptocurrency_card.hpp"
#include <iostream>
using namespace std;
int main()
{
    Customer t1;
    t1.set_age(21);
    t1.set_name("Bob");

    Credit_card *c1 = new Credit_card;
    Cryptocurrency_card *c2 = new Cryptocurrency_card;

    c1->set_balance(100);
    c1->set_cashback(23);
    c1->set_limit(-20);
    c1->set_number(12);

    c2->set_bitcoin(1.2);
    c2->set_commission(13);
    c2->set_course(103134.45);
    c2->set_number(22);

    vector<Card *> crds;
    crds.push_back(c1);
    crds.push_back(c2);

    t1.set_cards(crds);

    ATM a1;

    a1.operations(t1.give_card());

    cout << c1->get_balance() << " " << c2->get_balance() << "\n";
}