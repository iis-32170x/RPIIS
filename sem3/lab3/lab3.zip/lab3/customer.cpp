#include "human.hpp"
#include "card.hpp"
#include "customer.hpp"
#include "ATM.hpp"
#include <iostream>
#include <vector>
Customer::Customer() {}
Customer::~Customer() {}

void Customer::set_cards(std::vector<Card *> cards)
{
    this->cards = cards;
}

std::vector<Card *> Customer::get_cards() const { return this->cards; }

void Customer::add_card(Card *card)
{
    this->cards.push_back(card);
}

void Customer::remove_card()
{
    std::cout << "Choose position of card which will be deleted:\n";
    for (int i = 0; i < this->cards.size(); i++)
    {
        std::cout << i + 1 << ". " << this->cards[i]->get_number() << "\n";
    }
    int pos;
    std::cin >> pos;

    this->cards.erase(std::next(this->cards.begin(), pos - 1));
}

Card *Customer::give_card()
{
    std::cout << "Choose position of card which will be will be used:\n";
    for (int i = 0; i < this->cards.size(); i++)
    {
        std::cout << i + 1 << ". " << this->cards[i]->get_number() << "\n";
    }
    int pos;
    std::cin >> pos;
    return this->cards[pos - 1];
}