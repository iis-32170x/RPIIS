
#include <string>
#include <vector>
#include "ATM.hpp"
#include "manager.hpp"
#include "bank.hpp"

Bank::Bank() {}
Bank::~Bank() {}

void Bank::set_name(std::string name)
{
    this->name = name;
}
void Bank::set_managers(std::vector<Manager *> mngrs)
{
    this->managers = mngrs;
}
void Bank::set_atms(std::vector<ATM *> atms)
{
    this->atms = atms;
}
void Bank::set_key_rate(double kr)
{
    this->key_rate = kr;
}
void Bank::set_inflation(double infl)
{
    this->inflation = infl;
}

std::string Bank::get_name() const { return this->name; }
std::vector<Manager *> Bank::get_managers() const { return this->managers; }
std::vector<ATM *> Bank::get_atms() const { return this->atms; }
double Bank::get_key_rate() const { return this->key_rate; }
double Bank::get_inflation() const { return this->inflation; }
