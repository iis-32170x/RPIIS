#pragma once
class Card
{
protected:
    double balance = 0;
    long int number = 0;

public:
    Card();
    virtual ~Card();

    void set_balance(double balance);
    void set_number(long int number);

    double get_balance() const;
    long int get_number() const;

    virtual double withdrawal(double sum = 0) = 0;
    virtual void refill_balance(double sum) = 0;
};