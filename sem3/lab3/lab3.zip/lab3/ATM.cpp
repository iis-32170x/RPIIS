#include "ATM.hpp"
#include <iostream>
ATM::ATM() {}
ATM::~ATM() {}

void ATM::operations(Card *card) const
{
    double sum = 0;
    std::cout << "Choose operation:\n1. Withdrawal\n2. Refill balance\n";
    int operation_number;
    do
    {
        std::cin >> operation_number;
        if (operation_number > 2 || operation_number < 1)
        {
            std::cout << "Incorrect input\n";
        }
    } while (operation_number > 2 || operation_number < 1);

    std::cout << "Input sum: ";
    std::cin >> sum;

    if (operation_number == 1)
    {
        card->withdrawal(sum);
    }
    else
    {
        card->refill_balance(sum);
    }
}
