#pragma once
#include "card.hpp"
#include <iostream>
class Debit_card : public Card
{
private:
public:
    Debit_card();
    ~Debit_card();

    virtual double withdrawal(double sum = 0) override;
    virtual void refill_balance(double sum) override;
};