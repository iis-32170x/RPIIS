#pragma once
#include "department.hpp"
#include "customer.hpp"
#include <iostream>
#include "card.hpp"

class Exchange_department : public Department
{
private:
public:
    Exchange_department();
    ~Exchange_department();

    virtual void main_function(Customer *person) override;
};