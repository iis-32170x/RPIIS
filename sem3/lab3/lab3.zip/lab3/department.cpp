
#include <vector>
#include <string>
#include "employee.hpp"
#include "department.hpp"
#include "customer.hpp"

Department::Department() {}
Department::~Department() {}

void Department::set_effeciency(double eff)
{
    this->effeciency = eff;
}
void Department::set_employees(std::vector<Employee *> emp)
{
    this->employees = emp;
}
void Department::set_name(std::string name)
{
    this->name = name;
}

double Department::get_effeciency() const { return this->effeciency; }
std::vector<Employee *> Department::get_employees() const { return this->employees; }
std::string Department::get_name() const { return this->name; }