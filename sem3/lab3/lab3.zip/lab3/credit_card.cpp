#include "credit_card.hpp"
#include <iostream>
Credit_card::Credit_card() {}
Credit_card::~Credit_card() {}

void Credit_card::set_limit(double limit)
{
    this->limit = limit;
}
void Credit_card::set_cashback(int cashback)
{
    if (cashback > 0 && cashback < 100)
    {
        this->cashback = cashback;
    }
    else
    {
        this->cashback = 0;
    }
}

double Credit_card::get_limit() const { return this->limit; }
int Credit_card::get_cashback() const { return this->cashback; }

double Credit_card::withdrawal(double sum)
{
    if (sum == 0)
    {
        std::cout << "Input sum: ";
        std::cin >> sum;
    }
    if (this->balance - sum < limit)
    {
        std::cout << "You've reached limit. Operation was aborted\n";
    }
    else
    {
        double temp = 1 - (double(this->cashback) / 100);
        this->balance -= sum * temp;
    }
    return sum;
}
void Credit_card::refill_balance(double sum)
{
    this->balance += sum;
}