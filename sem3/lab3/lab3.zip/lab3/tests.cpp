#include <UnitTest++/UnitTest++.h>
#include "ATM.hpp"
#include "bank.hpp"
#include "card.hpp"
#include "CEO.hpp"
#include "credit_card.hpp"
#include "cryptocurrency_card.hpp"
#include "customer.hpp"
#include "debit_card.hpp"
#include "department.hpp"
#include "deposit_dep.hpp"
#include "employee.hpp"
#include "exchange_dep.hpp"
#include "human.hpp"
#include "manager.hpp"

TEST(atm_)
{
    Credit_card *t = new Credit_card;
    t->set_balance(12);
    t->set_cashback(12);
    t->set_limit(3);
    t->set_number(2222);

    ATM test;
    test.operations(t);
}
TEST(bank_)
{
    Bank test;
    test.set_inflation(12);
    test.set_key_rate(22);
    test.set_name("a");
    CHECK_EQUAL(test.get_inflation(), 12);
    CHECK_EQUAL(test.get_key_rate(), 22);
    CHECK_EQUAL(test.get_name(), "a");
}
TEST(CEO_)
{
    CEO c;
    c.set_age(12);
    c.set_iq(89);
    c.set_name("CLOWN");
    c.work();
    CHECK_EQUAL(c.get_age(), 12);
    CHECK_EQUAL(c.get_iq(), 91);
    CHECK_EQUAL(c.get_name(), "CLOWN");
    CHECK_EQUAL(c.get_salary(), 4);
}
TEST(credit_card_)
{
    Credit_card a;
    a.set_balance(120);
    a.set_cashback(12);
    a.set_limit(3);
    a.set_number(2);
    a.withdrawal(12);

    CHECK_EQUAL(a.get_balance(), 120 - 12 * 0.88);
    CHECK_EQUAL(a.get_cashback(), 12);
    CHECK_EQUAL(a.get_limit(), 3);
}
TEST(cryptocurrency_card_)
{
    Cryptocurrency_card a;
    a.set_bitcoin(33);
    a.set_commission(30);
    a.set_course(12);
    CHECK_EQUAL(a.get_balance(), 12 * 33);
    a.refill_balance(120);
    CHECK_EQUAL(a.get_balance(), 12 * 33 + 120);
    CHECK_EQUAL(a.get_course(), 12);
}
TEST(customer_)
{
    Customer a;
    a.set_age(88);
    a.set_name("BOB");
    CHECK_EQUAL(a.get_age(), 88);
    CHECK_EQUAL(a.get_name(), "BOB");
}
TEST(debit_card_)
{
    Debit_card a;
    a.set_balance(193);
    a.set_number(30);
    CHECK_EQUAL(a.get_balance(), 193);
    CHECK_EQUAL(a.get_number(), 30);
}
TEST(deposit_department_)
{
    Deposit_department d;
    d.set_effeciency(94.3);
    d.set_rate(12);
    d.set_name("Why");
    CHECK_EQUAL(d.get_effeciency(), 94.3);
    CHECK_EQUAL(d.get_rate(), 12);
    CHECK_EQUAL(d.get_name(), "Why");
}
TEST(exchange_dep_)
{

    Exchange_department a;
    a.set_effeciency(34);
    a.set_name("A");
    CHECK_EQUAL(a.get_effeciency(), 34);
    CHECK_EQUAL(a.get_name(), "A");
}
TEST(human_)
{
    Human a;
    a.set_age(122);
    a.set_name("ASD");
    CHECK_EQUAL(a.get_age(), 122);
    CHECK_EQUAL(a.get_name(), "ASD");
}
TEST(manager_)
{
    Manager a;
    a.set_age(55);
    a.set_name("SS");
    a.set_salary(3222);
    CHECK_EQUAL(a.get_age(), 55);
    CHECK_EQUAL(a.get_name(), "SS");
    CHECK_EQUAL(a.get_salary(), 3222);
}

int main()
{
    return UnitTest::RunAllTests();
}