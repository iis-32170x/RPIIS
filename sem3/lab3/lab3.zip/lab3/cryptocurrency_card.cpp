#include "cryptocurrency_card.hpp"
#include <iostream>
Cryptocurrency_card::Cryptocurrency_card() { this->balance = this->course * this->bitcoin; }
Cryptocurrency_card::~Cryptocurrency_card() {}

void Cryptocurrency_card::set_bitcoin(double bitcoin)
{
    if (bitcoin > 0)
    {
        this->bitcoin = bitcoin;
        this->balance = this->course * this->bitcoin;
    }
}
void Cryptocurrency_card::set_commission(int cmsn)
{
    if (commission > 0 && commission < 100)
    {
        this->commission = cmsn;
    }
}
void Cryptocurrency_card::set_course(double course)
{
    if (course > 0)
    {
        this->course = course;
        this->balance = this->course * this->bitcoin;
    }
}

double Cryptocurrency_card::get_bitcoin() const { return this->bitcoin; }
int Cryptocurrency_card::get_commission() const { return this->commission; }
double Cryptocurrency_card::get_course() const { return this->course; }

double Cryptocurrency_card::withdrawal(double sum)
{
    if (sum == 0)
    {
        std::cout << "Input sum: ";
        std::cin >> sum;
    }
    if ((this->bitcoin * this->course) + (sum * double(this->commission) / 100) < sum)
    {
        std::cout << "Not enough cash\n";
    }
    else
    {
        this->bitcoin = ((this->bitcoin * this->course) - (sum * (1 + double(this->commission) / 100))) / this->course;
        this->balance = this->course * this->bitcoin;
    }
    return sum;
}
void Cryptocurrency_card::refill_balance(double sum)
{
    this->bitcoin = ((this->bitcoin * this->course) + (sum * (1 - (double(this->commission) / 100)))) / this->course;
    this->balance = this->course * this->bitcoin;
}