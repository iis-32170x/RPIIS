#include "card.hpp"

Card::Card() {}
Card::~Card() {}

void Card::set_balance(double balance)
{
    this->balance = balance;
}
void Card::set_number(long int number)
{
    if (number > 0)
    {
        this->number = number;
    }
}

double Card::get_balance() const { return this->balance; }
long int Card::get_number() const { return this->number; }