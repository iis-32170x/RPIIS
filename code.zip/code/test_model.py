#!/usr/bin/env python

# Do *not* edit this script.

import numpy as np, os, sys
from team_code import load_model, run_model
from helper_code import *
from evaluate_model import evaluate_model,get_category_field,load_weights2,arrange_labels
import pandas as pd
import csv

# Test model.
def test_model(model_directory, data_directory, output_directory):
    # Find header and recording files.
    print('Finding header and recording files...')

    header_files, recording_files = find_challenge_files(data_directory)
    num_recordings = len(recording_files)

    if not num_recordings:
        raise Exception('No data was provided.')

    # Create a folder for the outputs if it does not already exist.
    if not os.path.isdir(output_directory):
        os.mkdir(output_directory)

    # Identify the required lead sets.
    required_lead_sets = set()
    for i in range(num_recordings):
        header = load_header(header_files[i])
        leads = get_leads(header)
        sorted_leads = sort_leads(leads)
        required_lead_sets.add(sorted_leads)

    # Load models.
    leads_to_model = dict()
    print('Loading models...')
    for leads in required_lead_sets:
        model = load_model(model_directory, leads) ### Implement this function!
        leads_to_model[leads] = model


    thres = 0.5
    # Run model for each recording.
    print('Running model...')


    labelsss = []
    presss = []
    prosss = []
    for i in range(num_recordings):
        print('    {}/{}...'.format(i+1, num_recordings))

        # Load header and recording.
        header = load_header(header_files[i])
        recording = load_recording(recording_files[i])
        leads = get_leads(header)
        sorted_leads = sort_leads(leads)

        # Apply model to recording.
        model = leads_to_model[sorted_leads]
        classes, labels, probabilities = run_model(model, header, recording) ### Implement this function!

        # Save model outputs.



        # load labels
        label_vector, current_labels = load_labels(header_files[i], classes)
        #print(classes)
        print(label_vector)





        labelsss.append(label_vector)
        presss.append(labels)
        prosss.append(probabilities)
        print(label_vector)
        print(labels)
        print(probabilities)
        
        res = open('./results.txt','a+')
        res.write('-----label-----%s-----:%s\n'%(str(i+1),label_vector))
        res.write('-----pre-----%s-----:%s\n'%(str(i+1),labels))
        res.write('-----pro-----%s-----:%s\n'%(str(i+1),probabilities))
        res.close()



    labelsss = np.array(labelsss,dtype='float32')
    presss = np.array(presss,dtype='float32')
    prosss = np.array(prosss,dtype='float32')


    scored_log_file = os.path.join(model_directory, 'test2_scorelog.csv')
    class_wise_scores_file = os.path.join(model_directory, 'test2_class-wise-scores.csv')

    _, auroc, auprc, auroc_classes, auprc_classes, accuracy, f_measure, f_beta_measure, challenge_metric, precision, recall = \
        evaluate_model(labelsss, presss, prosss, classes)

    class_wise_scores = {
        "class codes": classes,
        "class names": get_category_field(classes),
        # "frequency train": list(np.sum(Y, axis=0)),
        "frequency test": list(np.sum(labelsss, axis=0)),
        "auroc_classes": list(auroc_classes),
        "auprc_classes": list(auprc_classes),
        "precision": list(precision),
        "recall": list(recall),
        "F_measure_classes": list(f_beta_measure),
    }
    print('classes number: ', len(classes))
    print('auroc_classes number: ', len(auroc_classes))
    print('precision number: ', len(precision))
    print('F_measure_classes number: ', len(f_beta_measure))
    print(class_wise_scores)
    classwise_scores_df = pd.DataFrame(class_wise_scores)
    classwise_scores_df.to_csv(class_wise_scores_file[:-4] + '_thres' + str(thres) + class_wise_scores_file[-4:])

    cvscores = []
    score = [classes, auroc, auprc, auroc_classes, auprc_classes, accuracy, f_measure, f_beta_measure,
             challenge_metric]
    cvscores.append(score)

    print('----------- Segment classification scores -----------')
    print('auroc:', auroc)
    print('auprc:', auprc)
    print('auroc_classes:', auroc_classes)
    print('auprc_classes:', auprc_classes)
    print('accuracy:', accuracy)
    print('f_measure:', f_measure)
    print('Fbeta_measure:', f_beta_measure)
    print('challenge_metric:', challenge_metric)

    cvscores_head = ['classes', 'auroc', 'auprc', 'auroc_classes', 'auprc_classes', 'accuracy',
                     'f_measure', 'Fbeta_measure', 'challenge_metric']
    scored_log_file = scored_log_file[:-4] + '_thres' + str(thres) + scored_log_file[-4:]
    with open(scored_log_file, 'w', newline='') as out_f:  # Python 3
        w = csv.writer(out_f, delimiter=',')  # override for tab delimiter
        w.writerow(cvscores_head)
        w.writerows(cvscores)




    print('Done.')



def load_labels(header_file, classes):





    label_mapping = {'426783006': ['427393009', '426177001', '427084000'], # Sinus rhythm: SA, SB, STach
                          '426627000': ['426177001'],   # Brady: SB
                          # '17366009': ['164889003', '164890007', '713422000'], # Atrial arrhythmia: AF, AFL, ATach
                          '164889003': ['195080001', '426749004', '282825002', '314208002'], # AF: AFAFL, CAF, PAF, RAF
                          '164890007': ['195080001'],   # AFL: AFAFL
                          '3424008':  ['427084000', '713422000', '426648003', '164895002'],  # Tach: STach, ATach, JTach, VTach
                          '713422000': ['426761007'],   # ATach: SVT
                          '426761007': ['713422000', '67198005'],   # SVT: ATach, PSVT
                          '426648003': ['251166008', '233897008'],  # JTach: AVNRT, AVRT
                          '164895002': ['425856008', '111288001'],  # VTach: PVT, VFL
                          '60423000': ['65778007','5609005'], # SND: SAB, SARR
                          '29320008': ['426995002', '251164006', '426648003'],   # AVJR: JE, JPC, JTach
                          '284470004': ['63593006', '251170000', '251173003'],  # PAC: SVPB, BPAC, AB
                          '63593006': ['284470004'],    # SVPB: PAC
                          '427172004': ['164884008', '17338001', '251182009', '251180001', '11157007'], # PVC:
                                                                                # VEB, VPB, VPVC, VTrig, VBig
                          '164884008': ['427172004'],   # VEB: PVC
                          '17338001': ['427172004'],    # VPB: PVC
                          '6374002': ['164909002', '59118001'], # BBB: LBBB, RBBB
                          '164909002': ['445211001', '445118002', '251120003', '733534002'],    # LBBB: LPFB, LAnFB, ILBBB, CLBBB
                          '59118001': ['713427006', '713426002'],  # RBBB: CRBBB, IRBBB
                          '233917008': ['195039008', '27885002'],   # AVB: PAB, CHB
                          '195039008': ['270492004', '195042002'],  # PAB: IAVB, IIAVB
                          '195042002': ['426183003', '54016002'],   # IIAVB: IIAVBII, MoI
                          '49260003': ['61277005', '13640000', '11157007', '75532003', '81898007'], # IR: AIVR, FB, VBig, VEsB, VEsR
                          '195126007': ['446813000', '446358003'],  # AH: LAH, RAH
                          '67741000119109': ['446813000'], # LAE: LAH
                          '266249003': ['164873001', '89792004'],   # VH: LVH, RVH
                          '164873001': ['55827005'],    # LVH: LVHV
                          '55827005': ['164873001'],    # LVHV: LVH
                          '253339007': ['67751000119106'], # RAAb: RAHV
                          '67751000119106': ['446358003'],   # RAHV: RAH
                          '365418004': ['164934002', '251259000', '59931005'], # T wave findings: TAb, HTV, TInV
                          '55930002': ['164930006', '428750005', '429622005', '164931005'], # STC: STIAb, NSSTTA, STD, STE
                          '164861001': ['426434006', '425419005', '425623009', '413444003', '413844008'],    # MIs:
                                                                                # AnMIs, IIs, LIs, AMIs, CMI
                          '164865005': ['164867002', '57054005'],   # MI: OldMI, AMI
                          '57054005': ['54329005'],     # AMI: AnMI
                          }





    header = load_header(header_file)
    print(header)
    num_classes = len(classes)
    print(classes)

    labels = get_labels(header)
    print(labels)


    new_labels = apply_label_mapping(label_mapping, labels)

    print(new_labels)


    label_vector = np.zeros((num_classes,), dtype='float32')

    

    for label in new_labels:
        if label in classes:
            j = classes.index(label)
            label_vector[j] = 1

    return label_vector, labels

def apply_label_mapping(label_mapping, labels):
    new_labels = labels.copy()
    for supertype, subtypes in label_mapping.items():
        if any(label in new_labels for label in subtypes) and supertype not in new_labels:
            new_labels.append(supertype)
    return new_labels



if __name__ == '__main__':
    # Parse arguments.
    if len(sys.argv) != 4:
        raise Exception('Include the model, data, and output folders as arguments, e.g., python test_model.py model data outputs.')

    model_directory = sys.argv[1]
    data_directory = sys.argv[2]
    output_directory = sys.argv[3]

    test_model(model_directory, data_directory, output_directory)
