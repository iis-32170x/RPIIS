# Import libraries
import sys, argparse, os
import numpy as np
from numpy.core.fromnumeric import squeeze
import torch
import csv
import random
from collections import defaultdict
from sklearn.metrics.pairwise import cosine_similarity
import math
import pickle
import itertools

from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import Subset, DataLoader
import torch.nn.functional as F 

from utils.utils import *
from data import get_data
from data.ecg_stand import collate_fn_padd, ecg_classes
from models import get_model
from models import *
from utils.evaluate_model import *
from dev.feature_extractor import precompute_covariates

if 'ipykernel' in sys.modules:
    from tqdm import tqdm_notebook as tqdm
else:
    from tqdm.auto import tqdm, trange

parser = argparse.ArgumentParser()

### general parameters ################################################
parser.add_argument(
    '--mode', default="test_train",
    type=str)  #choices=["only_test","test_train"],help="mode to be run")
parser.add_argument("--save-dir", type=str, help="folder to save results")
parser.add_argument("--model-filename",
                    type=str,
                    help="name to use to save model")
parser.add_argument("--save-model",
                    default="last",
                    choices=['last', 'best', 'No'],
                    help="which model to use for testing and saving")
parser.add_argument('--resume',
                    type=str,
                    default=None,
                    help='put the path to resuming file if needed')
parser.add_argument("--root",
                    default="/Users/giulia/Documents/ECG_challenge",
                    type=str,
                    help="root folder")
parser.add_argument('--tag', default="__", type=str)
parser.add_argument("--val-every-n-epochs",
                    type=int,
                    default=1,
                    help="interval of training epochs to run the validation")
parser.add_argument("--experiment-folder",
                    default="/Users/giulia/Documents/ECG_challenge",
                    type=str,
                    help="experiment folder")

### k-fold cross validation ########################################
parser.add_argument("--fold-test",
                    type=int,
                    default=0,
                    help="k fold run used for testing")
parser.add_argument("--n-kfold", type=int, default=5, help="How many folds?")

### data parameters ################################################
parser.add_argument("--data",
                    default="ecg_data",
                    type=str,
                    choices=["ecg_data"],
                    help="dataset selection")
parser.add_argument("--data-path",
                    default="/scratch/tmp/full_train_ROIZ_2016_summer.pkl",
                    type=str,
                    help="location of the data")
parser.add_argument("--resamp-freq",
                    type=int,
                    default=125,
                    help="resample the data to this frequency")
parser.add_argument(
    "--save-covariates",
    default=False,
    action="store_true",
    help="only compute covariates once, and if they are computed reuse them")
parser.add_argument("--recompute-covariates",
                    default=False,
                    action="store_true",
                    help="if set, covariates are recomputed")
parser.add_argument("--covariates-save-path",
                    default="features/",
                    type=str,
                    help="location to store the covariates")
parser.add_argument(
    "--num-processes",
    type=int,
    default=1,
    help='number of processes used to compute features [default=%(default)s].')

### optimizer parameters ################################################
parser.add_argument('--optimizer', default='sgd', choices=['sgd', 'adam'])
parser.add_argument("--epochs",
                    type=int,
                    default=20,
                    help='Maximum number of epochs [default=%(default)s].')
parser.add_argument("--logstep-train",
                    default=50,
                    type=int,
                    help="iterations step for training log")
parser.add_argument("--lr",
                    type=float,
                    default=0.001,
                    help='Optimizer initial learning rate')
parser.add_argument("--momentum",
                    type=float,
                    default=0.9,
                    help='momentum for sgd')
parser.add_argument(
    "--batch-size",
    type=int,
    default=600,
    help='Batch size for train, validation and test sets [default=%(default)s].'
)
parser.add_argument("--num-workers",
                    type=int,
                    default=0,
                    help='Num workers for dataloaders [default=%(default)s].')
parser.add_argument("--scheduler",
                    default="no",
                    choices=['no', 'exp'],
                    help='add scheduler default=no')
parser.add_argument("--scheduler-decay-factor",
                    type=float,
                    default=0.9,
                    help='Learning rate decay factor [default=%(default)s].')
parser.add_argument("--scheduler-step",
                    type=str,
                    default="epoch",
                    choices=["epoch", "iter"],
                    help='how often a scheduler step is taken')
parser.add_argument(
    "--weight-decay",
    type=float,
    default=0.,
    help='Add L2 regularization to the loss function [default=%(default)s].')

### model parameters ################################################
parser.add_argument(
    "--model",
    type=str,
    default='Conv1dNet',
    choices=['Conv1dNet', 'Conv1dNet_10s', 'GRU', 'LSTM', 'TCN', 'ResNet1d'],
    help='Model to use [default=%(default)s].')
parser.add_argument("--n-channels",
                    type=int,
                    default=12,
                    help="number of ECG channels")
parser.add_argument("--num-class",
                    type=int,
                    default=30,
                    help="number of classes")
parser.add_argument(
    "--n-covariates",
    type=int,
    default=0,
    help="number of additioanl manual features to add to last layer")
parser.add_argument("--use-covariates",
                    action="store_true",
                    default=False,
                    help="whether or not to use handcrafted features")
parser.add_argument("--loss",
                    type=str,
                    default='BCE',
                    choices=['BCE', 'ASL', 'challenge'],
                    help='Loos to use [default=%(default)s].')
parser.add_argument("--gamma-neg",
                    type=int,
                    default=3,
                    help='contribution of negative samples to ASL loss')
parser.add_argument("--gamma-pos",
                    type=int,
                    default=1,
                    help='contribution of positive samples to ASL loss')

### label correction parameters #####################################
parser.add_argument("--label-correction", default=False,
                    action="store_true")  #choices=[True,False])
parser.add_argument("--start-epoch",
                    type=int,
                    default=1,
                    help='Number of epochs before label correction phase')
parser.add_argument("--alpha-label", type=float, default=0.5)
parser.add_argument("--percent-samples", type=float, default=0.2)
parser.add_argument("--num-prototypes", type=int, default=5)
parser.add_argument("--selection-threshold", type=int, default=0.9)


### for GRU
### TO DO add hidden_channels, num_layers


class DevelopingSuite(object):
    def __init__(self, args):

        self.args = args
        self.data_train, self.data_val = get_data(args)

        # Define torch dataloader object

        self.train_dataloader = DataLoader(self.data_train,
                                           batch_size=args.batch_size,
                                           num_workers=args.num_workers,
                                           drop_last=True,
                                           shuffle=True,
                                           collate_fn=collate_fn_padd)
        self.val_dataloader = DataLoader(self.data_val,
                                         batch_size=args.batch_size,
                                         num_workers=args.num_workers,
                                         collate_fn=collate_fn_padd)

        #self.test_dataloader = DataLoader(self.data_test, batch_size=args.batch_size, num_workers=args.num_workers, collate_fn=collate_fn_padd)

        args.n_covariates = next(iter(
            self.train_dataloader))["covariates"].shape[1]

        # Use GPU if available
        print('GPU devices available:', torch.cuda.device_count())
        self.device = torch.device(
            'cuda' if torch.cuda.is_available() else 'cpu')
        print('Using device:', self.device)

        self.model = get_model(args)
        self.model.to(self.device)

        self.experiment_folder = args.save_dir

        if args.resume is not None:

            #self.resume(path=args.resume)

            raise NotImplemented

        if "train" in args.mode:
            #self.experiment_folder = new_log(args.save_dir,args.model + "_" + args.tag,args=args)
            if not os.path.isdir(self.experiment_folder):
                os.mkdir(self.experiment_folder)
            self.writer = SummaryWriter(log_dir=self.experiment_folder)

            if args.optimizer == 'adam':
                self.optimizer = torch.optim.Adam(
                    self.model.parameters(),
                    lr=args.lr,
                    weight_decay=self.args.weight_decay)
            elif args.optimizer == 'sgd':
                self.optimizer = torch.optim.SGD(
                    self.model.parameters(),
                    lr=args.lr,
                    momentum=self.args.momentum,
                    weight_decay=self.args.weight_decay)

            if args.scheduler == "exp":
                self.scheduler = torch.optim.lr_scheduler.ExponentialLR(
                    self.optimizer, gamma=self.args.scheduler_decay_factor)
                #self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(self.optimizer, patience=1, factor=args.lr_decay_factor, mode='max', verbose=True)
            elif args.scheduler == "no":
                self.scheduler = None
            else:
                print("scheduler unknown")
                print(args.scheduler)

            if args.label_correction == True:
                self.label_correction = True
                self.start_epoch = args.start_epoch
                self.alpha_label = args.alpha_label
                self.percent_samples = args.percent_samples
                self.num_prototypes = args.num_prototypes
                self.selection_threshold = args.selection_threshold
                print("Label correction phase performed")
            else:
                self.label_correction = False

            self.startLC = False
            self.epoch = 0
            self.iter = 0
            self.train_stats = {}
            self.val_stats = {}
            self.lastepoch = False

            self.early_stopping = EarlyStopping()  #initialize early stopping

    def train_and_eval(self):

        self.val_stats["validation_loss"] = torch.tensor(float('nan'))
        self.val_stats["challenge_loss"] = torch.tensor(float('nan'))
        self.val_stats["best_validation_loss"] = torch.tensor(float('nan'))
        self.val_stats["validation_accuracy"] = torch.tensor(float('nan'))
        with tqdm(range(0, self.args.epochs), leave=True) as tnr:
            tnr.set_postfix(
                challenge_loss=self.val_stats["challenge_loss"],
                best_validation_loss=self.val_stats["best_validation_loss"],
                validation_loss=self.val_stats["validation_loss"],
                accuracy=self.val_stats["validation_accuracy"])
            for n, self.epoch in enumerate(tnr):
                if self.label_correction:
                    if not self.startLC:
                        self.training(tnr)
                        self.args.start_epoch = n + 1
                    else:
                        if n == self.args.start_epoch:
                            print("...start label correction phase...")
                            self.val_stats[
                                "best_validation_loss"] = torch.tensor(
                                    float('nan'))
                            #self.val_stats["validation_loss"] = torch.tensor(float('nan'))
                            self.val_stats["challenge_loss"] = torch.tensor(
                                float('nan'))
                            self.early_stopping = EarlyStopping(
                            )  # re-initialize early stopping
                            data_model = torch.load(os.path.join(
                                self.experiment_folder,
                                self.args.model_filename),
                                map_location=self.device)
                            self.model.load_state_dict(
                                data_model['model_state_dict'])

                        if n + 1 == self.args.epochs:
                            self.lastepoch = True

                        self.training_and_labelCorrection(tnr)

                    if self.epoch % self.args.val_every_n_epochs == 0:
                        self.validate()

                        self.early_stopping(self.val_stats["challenge_loss"])
                        if self.early_stopping.early_stop:
                            if not self.startLC:
                                self.startLC = True
                            else:
                                break

                    if self.scheduler is not None and self.args.scheduler_step == "epoch":
                        self.scheduler.step()
                        self.writer.add_scalar(
                            'log_learning_rate',
                            np.log10(self.scheduler.get_lr()), self.iter)
                else:
                    self.training(tnr)

                    if self.epoch % self.args.val_every_n_epochs == 0 and self.args.val_every_n_epochs != -1:
                        self.validate()

                        self.early_stopping(self.val_stats["challenge_loss"])
                        if self.early_stopping.early_stop:
                            break

                    if self.scheduler is not None and self.args.scheduler_step == "epoch":
                        self.scheduler.step()
                        self.writer.add_scalar(
                            'log_lr', np.log10(self.scheduler.get_lr()),
                            self.iter)

        if self.args.save_model == "last":
            self.save_model()

        metrics = ['ChallengeScore']
        values = [1 - self.val_stats["best_validation_loss"]]

        # save metrics
        if not os.path.exists(self.args.experiment_folder):
            os.makedirs(self.args.experiment_folder)
        with open(
                self.args.experiment_folder + 'exp_' +
                str(self.args.n_channels) + '_' + self.args.model + '_' +
                self.args.loss + '_' + self.args.tag +
                str(self.args.fold_test) + '.csv', 'w') as csv_file:
            csv_writer = csv.writer(csv_file, delimiter=',')
            csv_writer.writerow(metrics)
            csv_writer.writerow(values)

    def training(self, tnr=None):

        self.model.train()
        accumulated_loss, accumulated_main_loss, accumulated_func_eval = 0, 0, 0

        with tqdm(self.train_dataloader, leave=False) as inner_tnr:
            for en, sample in enumerate(inner_tnr):

                x = sample["ecg"]
                y = sample["labels"]
                covariates = sample["covariates"]
                mask = sample["mask"]
                x, y, covariates, mask = x.to(self.device), y.to(
                    self.device), covariates.to(self.device), mask.to(
                        self.device)

                self.optimizer.zero_grad()

                pred_y = self.model(x, covariates, mask).squeeze()
                loss = self.model.criterion(pred_y, y)

                # Backward pass
                loss.backward()
                self.optimizer.step()

                accumulated_loss += loss.item()

                self.iter += 1

                # adjust learning rate
                if self.scheduler is not None and self.args.scheduler_step == "iter":
                    self.scheduler.step()
                    self.writer.add_scalar('log_lr',
                                           np.log10(self.scheduler.get_lr()),
                                           self.iter)

                # log progress
                if (en + 1) % self.args.logstep_train == 0:
                    self.train_stats[
                        'train_loss'] = accumulated_loss / self.args.logstep_train
                    func_eval = accumulated_func_eval / (
                        self.args.logstep_train)
                    accumulated_loss, accumulated_func_eval = 0., 0.
                    inner_tnr.set_postfix(
                        training_loss=self.train_stats['train_loss'])
                    if tnr is not None:
                        tnr.set_postfix(
                            training_loss=self.train_stats['train_loss'],
                            challenge_loss=self.val_stats["challenge_loss"],
                            best_validation_loss=self.
                            val_stats["best_validation_loss"],
                            validation_loss=self.val_stats["validation_loss"],
                            accuracy=self.val_stats["validation_accuracy"])

                    self.writer.add_scalar('training/training loss',
                                           self.train_stats['train_loss'],
                                           self.iter)
                    # TODO: this is not computed
                    #  self.writer.add_scalar('training/func_eval', func_eval,
                    #  self.iter)

    def training_and_labelCorrection(self, tnr=None):
        '''
        Self-learning with Multi-Prototypes to train a network on a real noisy dataset without extra supervision.

        ref:
        Han, Jiangfan, Ping Luo, and Xiaogang Wang. "Deep self-learning from noisy labels."
        Proceedings of the IEEE/CVF International Conference on Computer Vision. 2019.
        '''

        saving_var = defaultdict(list)
        self.model.eval()
        accumulated_loss, accumulated_main_loss, accumulated_func_eval = 0, 0, 0
        with tqdm(self.train_dataloader, leave=False) as inner_tnr:
            inner_tnr.set_postfix(training_loss_main=torch.tensor(
                float('nan')),
                training_loss=torch.tensor(float('nan')))

            data_indices = [
                indices for indices in self.train_dataloader.batch_sampler
            ]

            # get all samples from each class label
            num_classes = self.data_train.num_classes
            classes = self.data_train.classes
            labels = self.data_train.labels
            merged = list(itertools.chain(*labels))
            num_labels_class = [merged.count(l) for l in classes]

            classes_list = [[
                idx for idx, c in enumerate(labels) if unique_class in c
            ] for unique_class in classes]
            classes_present = [
                idx for idx, c in enumerate(classes_list) if len(c) > 0
            ]
            num_classes_present = len(classes_present)

            # get random samples from each class
            class_inds = [
                random.sample(list(classes_list[i]),
                              int(self.percent_samples * num_labels_class[i]))
                for i in range(num_classes) if len(classes_list[i]) > 0
            ]
            dataloaders = [
                DataLoader(dataset=Subset(self.data_train, inds),
                           batch_size=10, # was 100 but run out of GPU memory
                           shuffle=True,
                           drop_last=False,
                           collate_fn=collate_fn_padd) for inds in class_inds
            ]

            num_l_c = [i for i in num_labels_class if i != 0]

            # feature extraction
            # function to call the hook signature and store the output
            activation = {}

            def get_activation(name):
                def hook(model, input, output):
                    activation[name] = output.detach()

                return hook

            # get hook for layer and features, layer where we want the hook for feature extraction (before FC)
            self.model.lastpool.register_forward_hook(
                get_activation('lastpool'))

            # get features for the random samples of each class
            features_classes = [] #defaultdict(list)

            for en2, c in enumerate(dataloaders):
                features_class = [] 
                for sample2 in c:
                    x2 = sample2["ecg"]
                    cov2 = sample2["covariates"]
                    mask2 = sample2["mask"]
                    x2, cov2, mask2 = x2.to(self.device), cov2.to(
                        self.device), mask2.to(self.device)
                    self.model(x2, cov2, mask2)
                    features_y = activation['lastpool'].data.cpu().numpy()
                    # get rid of one dimension
                    fatures_y = features_y[:,:,0]
                    features_class.append(fatures_y)
 
                features_classes.append(np.vstack(features_class))

             # prototype selection
            prototypes_classes = []
            for X in features_classes:
                n_features = X.shape[1]

                # compute similarities and densities
                S = cosine_similarity(X)
                s_c = np.quantile(S, 0.75)
                sign_matrix = np.sign(S - s_c)
                densities = np.sum(sign_matrix, axis=0)

                # sort densities in descending order
                idx = (-densities).argsort()

                # select prototypes
                prototypes = np.zeros((self.num_prototypes, n_features),
                dtype=np.float32)
                prototypes[0] = X[idx[0]]
                prototypes_idx = [idx[0]]
                prototypes_found = 1

                # selection is slightly different than in the paper, similarities are only considered to other samples that were selected as prototypes
                # In my (Julians) opinion this makes more sense
                for e, i in enumerate(idx[1:]):
                    if prototypes_found >= self.num_prototypes:
                        break
                    valid_values = [S[i, j] for j in prototypes_idx]
                    # valid_values = [S[i, j] for j in idx[:(e+1)]]
                    sim_measure = np.max(valid_values)
                    if sim_measure < self.selection_threshold:
                        prototypes[prototypes_found] = X[i]
                        prototypes_idx.append(i)
                        prototypes_found += 1

                prototypes_classes.append(prototypes)

            prototypes_classes = [
            torch.from_numpy(p).to(self.device) for p in prototypes_classes
            ]

            self.model.train()

            # Batch training and feature extraction of samples from batch for label correction
            data_files = []
            for en, sample in enumerate(inner_tnr):

                x = sample["ecg"]
                y = sample["labels"]
                covariates = sample["covariates"]
                mask = sample["mask"]
                x, covariates, mask, y = x.to(self.device), covariates.to(
                    self.device), mask.to(self.device), y.to(self.device)

                self.optimizer.zero_grad()

                pred_y = self.model(x, covariates,
                                    mask).squeeze()  #predicted labels

                # get hook for layer and features, layer where we want the hook for feature extraction (before FC)
                self.model.lastpool.register_forward_hook(
                    get_activation('lastpool'))
                features_x = activation['lastpool'].data
                features_sample = torch.squeeze(features_x)
                # normalize features
                features_sample = F.normalize(features_sample)
                #similarity scoreand label correction
                similarities = [
                    torch.matmul(features_sample, prototypes.T)
                    for prototypes in prototypes_classes
                    
                ]
                
                similarity_scores = [
                    torch.mul(torch.sum(S,dim=1), 1/self.num_prototypes)
                    for S in similarities
                ]
                
                similarity_scores = torch.vstack(similarity_scores)
                
                # corrected label
                y_corrected = torch.argmax(similarity_scores, dim=0).cpu().numpy()

                # transform it to a tensor representation
                array = np.zeros((len(features_sample), num_classes))
                for i, f in enumerate(y_corrected):
                    array[i][classes_present[f]] = 1

                y_c = torch.from_numpy(array)  #corrected label

                if self.lastepoch:

                    for idx, s in enumerate(y):
                        if any(s != y_c[idx]) and len(torch.nonzero(s)) > 0:
                            label_true = classes[torch.where(
                                s.numpy() == 1)[0][0]]
                            label_corrected = classes[torch.where(
                                y_c[idx] == 1)[0][0]]
                            fname = self.data_train.header_files[
                                data_indices[en][idx]]
                            saving_var['true'].append(label_true)
                            saving_var['corrected'].append(label_corrected)
                            saving_var['file'].append(fname)

                # calculate loss
                loss1 = self.model.criterion(pred_y, y)
                loss2 = self.model.criterion(pred_y, y_c.to(self.device))
                loss = (1 -
                        self.alpha_label) * loss1 + self.alpha_label * loss2

                # Backward pass
                loss.backward()
                self.optimizer.step()

                accumulated_loss += loss.item()

                self.iter += 1

                if self.scheduler is not None and self.args.scheduler_step == "iter":
                    self.scheduler.step()
                    self.writer.add_scalar('log_lr',
                                           np.log10(self.scheduler.get_lr()),
                                           self.iter)

                if (en + 1) % self.args.logstep_train == 0:
                    self.train_stats[
                        'train_loss'] = accumulated_loss / self.args.logstep_train
                    func_eval = accumulated_func_eval / (
                        self.args.logstep_train)
                    accumulated_loss, accumulated_func_eval = 0., 0.
                    inner_tnr.set_postfix(
                        training_loss=self.train_stats['train_loss'])
                    if tnr is not None:
                        tnr.set_postfix(
                            training_loss=self.train_stats['train_loss'],
                            challenge_loss=self.val_stats["challenge_loss"],
                            best_validation_loss=self.
                            val_stats["best_validation_loss"],
                            validation_loss=self.val_stats["validation_loss"],
                            accuracy=self.val_stats["validation_accuracy"])

                    self.writer.add_scalar('training/training loss',
                                           self.train_stats['train_loss'],
                                           self.iter)
                    # TODO: this is not computed
                    #  self.writer.add_scalar('training/func_eval', func_eval,
                    #  self.iter)

        if self.lastepoch:
            with open(
                    os.path.join(self.experiment_folder,
                                 'corrected_labels.pickle'), 'wb') as f:
                pickle.dump(saving_var, f)

    def validate(self, tnr=None, save=True):

        total_dataset_size = 0
        total_loss = 0
        challenge_loss = 0
        total_accuracy = 0
        total_f1_score = 0
        batch_y_all = []
        pred_y_all = []

        nclasses = len(self.data_train.classes)
        acc = torch.zeros(nclasses).to(self.device)
        pos = torch.zeros(nclasses).to(self.device)

        outputs_all = torch.zeros(0, nclasses).to(self.device)
        labels_all = torch.zeros(0, nclasses).to(self.device)
        score_all = torch.zeros(0, nclasses).to(self.device)

        dataloader = self.val_dataloader
        self.model.eval()
        for sample in dataloader:
            with torch.no_grad():
                x = sample["ecg"]
                y = sample["labels"]
                covariates = sample["covariates"]
                mask = sample["mask"]

                x, y, covariates, mask = x.to(self.device), y.to(
                    self.device), covariates.to(self.device), mask.to(
                        self.device)
                batch_size = x.size(0)
                pred_y = self.model(x, covariates, mask).squeeze(1)

                y_pred_binary = 0.5 * (torch.sign(torch.sigmoid(pred_y) - 0.5)
                                       + 1).to(self.device)

                outputs_all = torch.cat((outputs_all, y_pred_binary))
                labels_all = torch.cat((labels_all, y))

                # Add metrics of current batch
                total_dataset_size += batch_size
                total_loss += self.model.loss(
                    pred_y,
                    y) * batch_size  # assuming mean reduction in loss function

        weights_file = 'weights_duplicates.csv'
        normal_class = '426783006'

        # Load the scored classes and the weights for the Challenge metric.
        classes, weights = load_weights(weights_file)
        classes = [c for cl in classes for c in cl]

        indices = [classes.index(x) for x in ecg_classes]
        weights = weights[np.ix_(indices, indices)]

        challenge_loss = 1 - compute_challenge_metric(
            weights,
            labels_all.cpu().numpy(),
            outputs_all.cpu().numpy(), ecg_classes, normal_class)
        total_accuracy += 0  #compute_total_matches(y, pred_y)

        # Average metrics over the whole dataset
        total_loss /= total_dataset_size
        total_accuracy /= total_dataset_size

        #self.val_stats["validation_loss"] = total_loss.item()
        self.val_stats["validation_loss"] = challenge_loss
        self.val_stats["validation_accuracy"] = 0  #total_accuracy.item()
        self.val_stats["challenge_loss"] = challenge_loss
        '''
        if not self.val_stats["best_validation_loss"] < self.val_stats["validation_loss"]:
            self.val_stats["best_validation_loss"] = self.val_stats["validation_loss"]
            if save and self.args.save_model == "best" or self.epoch < self.start_epoch:
                self.save_model()
        '''
        if not self.val_stats["best_validation_loss"] < self.val_stats[
                "challenge_loss"]:
            self.val_stats["best_validation_loss"] = self.val_stats[
                "challenge_loss"]
            if save and self.args.save_model == "best":
                self.save_model()
        '''
        if save and self.args.save_model == "last" and self.epoch >= self.start_epoch:
            self.save_model()
        '''
        self.writer.add_scalar('validation/validation loss',
                               self.val_stats["validation_loss"], self.epoch)
        self.writer.add_scalar('validation/best validation loss',
                               self.val_stats["best_validation_loss"],
                               self.epoch)
        self.writer.add_scalar('validation/accuracy',
                               self.val_stats["validation_accuracy"],
                               self.epoch)

        return

    def save_model(self):

        covariates_tmp = self.args.covariates
        self.args.covariates = []
        torch.save(
            {
                'epoch': self.epoch,
                'model_state_dict': self.model.state_dict(),
                'optimizer_state_dict': self.optimizer.state_dict(),
                'args': self.args
            }, os.path.join(self.experiment_folder, self.args.model_filename))
        self.args.covariates = covariates_tmp

    def eval_model_stats(self):

        data_model = torch.load(
            os.path.join(self.experiment_folder, self.args.model_filename))

        #data_model = torch.load("./runs/12_lead_model.pth")
        self.model.load_state_dict(data_model['model_state_dict'])

        #evaluation
        self.model.eval()
        nclasses = len(self.data_train.classes)
        acc = torch.zeros(nclasses).to(
            self.device
        )  # <-- changed so it the number of classes is automatic
        pos = torch.zeros(nclasses).to(
            self.device)  # <-- changed so it is automatic

        outputs_all = torch.zeros(0, nclasses).to(
            self.device)  # <-- changed so it is automatic
        labels_all = torch.zeros(0, nclasses).to(
            self.device)  # <-- changed so it is automatic
        score_all = torch.zeros(0, nclasses).to(
            self.device)  # <-- changed so it is automatic

        tot = 0
        dataloader = self.val_dataloader
        with torch.no_grad():
            for sample in tqdm(dataloader):
                x_t = sample["ecg"]
                y_t = sample["labels"]
                covariates = sample["covariates"]
                mask = sample["mask"]

                tot = tot + x_t.shape[0]
                y_pred = self.model(x_t, covariates, mask)  #.squeeze()
                y_pred_binary = 0.5 * (torch.sign(torch.sigmoid(y_pred) - 0.5)
                                       + 1).to(self.device)

                outputs_all = torch.cat((outputs_all, y_pred_binary), 0)
                labels_all = torch.cat((labels_all, y_t), 0)
                score_all = torch.cat((score_all, y_pred), 0)

                acc = acc + torch.sum(y_pred_binary == y_t, dim=0)
                pos = pos + torch.sum(y_t, dim=0)

                #assert(1==0)

        return acc, pos, outputs_all, labels_all, score_all


if __name__ == '__main__':

    args = parser.parse_args()

    # compute handcrafted features first
    if args.use_covariates:
        args.covariates = precompute_covariates(args)
    else:
        args.covariates = []

    developingSuite = DevelopingSuite(args)
    e = developingSuite.train_and_eval()
    developingSuite.writer.close()
