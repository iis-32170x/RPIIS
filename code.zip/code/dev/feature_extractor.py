import sys

import numpy as np
from biosppy.signals import ecg
import neurokit2 as nk
import helper_code
import torchaudio
import torch
from helper_code import *
import os, re
from pyentrp import entropy as ent
from neurokit2.complexity.entropy_approximate import entropy_approximate
from neurokit2.complexity.entropy_sample import entropy_sample
from neurokit2.complexity.entropy_shannon import entropy_shannon
import pywt
from joblib import Parallel, delayed
from tqdm import tqdm
from sklearn.preprocessing import MinMaxScaler
import data.ecg_stand
import pandas as pd


def preprocess_recording(recording, header, leads, signal_frequency):
    # only select the set of leads given in leads
    # and do some transformations and resampling

    leads_in_header = helper_code.get_leads(header)
    lead_indices = [leads_in_header.index(lead) for lead in leads]

    # get sampling rate, adu, and baseline from header
    orig_freq = helper_code.get_frequency(header)
    baseline = helper_code.get_baselines(header, leads)
    adu = helper_code.get_adc_gains(header, leads)

    # load recording into tensor
    recording = recording[lead_indices, :]
    recording = ((recording.transpose() - baseline) / adu).transpose()

    recording = torch.Tensor(recording).float()
    # resample it
    if orig_freq != signal_frequency:
        resample_transform = torchaudio.transforms.Resample(
            orig_freq, signal_frequency)
        recording = resample_transform(recording)

    return recording


def extract_sex(header):
    if helper_code.get_sex(header) == 'Female':
        sex = 0.25
    else:
        sex = 0.75
    return sex


def extract_age(header):
    age = helper_code.get_age(header)
    if pd.isnull(age):
        return 0
    else:
        return age / 100


def extract_time_features(filtered_recording, bpm, r_peaks,
                          signal_time_reference, signal_frequency):

    time_features = []

    _, waves_onoffset = nk.ecg_delineate(filtered_recording,
                                         r_peaks,
                                         method="dwt",
                                         sampling_rate=signal_frequency,
                                         show=False,
                                         check=True)

    ts = signal_time_reference

    # Remove all NaNs from waves:

    # Remove nans from segments wave:
    nans_in_t = np.isnan(waves_onoffset['ECG_T_Peaks']) | np.isnan(
        waves_onoffset['ECG_T_Onsets']) | np.isnan(
            waves_onoffset['ECG_T_Offsets'])
    nans_in_p = np.isnan(waves_onoffset['ECG_P_Peaks']) | np.isnan(
        waves_onoffset['ECG_P_Onsets']) | np.isnan(
            waves_onoffset['ECG_P_Offsets'])

    nans_in_wave_peaks = np.isnan(waves_onoffset['ECG_P_Peaks']) | np.isnan(
        waves_onoffset['ECG_T_Peaks'])

    nans_in_r = np.isnan(waves_onoffset['ECG_R_Onsets']) | np.isnan(
        waves_onoffset['ECG_R_Offsets'])

    nan_locations = nans_in_t | nans_in_p | nans_in_r

    for k in waves_onoffset.keys():
        waves_onoffset[k] = (np.array(
            waves_onoffset[k])[~nan_locations]).astype(int)

    r_peaks = r_peaks[~nans_in_wave_peaks]

    # P Wave Duration:
    p_wave_durations = ts[waves_onoffset['ECG_P_Offsets']] - ts[
        waves_onoffset['ECG_P_Onsets']]

    # QRS Complex Durations
    qrs_complex_durations = ts[waves_onoffset['ECG_R_Offsets']] - ts[
        waves_onoffset['ECG_R_Onsets']]

    # PR interval
    pr_intervals = ts[waves_onoffset['ECG_R_Onsets']] - ts[
        waves_onoffset['ECG_P_Onsets']]

    # T-wave durations
    t_wave_durations = ts[waves_onoffset['ECG_T_Offsets']] - ts[
        waves_onoffset['ECG_T_Onsets']]

    # P Wave Amplitudes
    p_wave_amplitudes = filtered_recording[waves_onoffset['ECG_P_Peaks']]

    # T Wave Amplitudes
    t_wave_amplitudes = filtered_recording[waves_onoffset['ECG_T_Peaks']]

    # Compute Ratios
    # ==============

    # QRS / P Duration
    rat_qrs_p_duration = qrs_complex_durations / p_wave_durations

    # QRS / T Duration
    rat_qrs_t_duration = qrs_complex_durations / t_wave_durations

    # RR Intervals
    rr_intervals = np.diff(ts[r_peaks])

    # numpy does not like it if the arguments have length 0
    def safe_mean_std(arr):
        if len(arr) > 0:
            return [np.mean(arr), np.std(arr)]
        else:
            return [0 for _ in range(2)]

    time_features.extend(safe_mean_std(rat_qrs_p_duration))
    time_features.extend(safe_mean_std(rat_qrs_t_duration))
    time_features.extend(safe_mean_std(pr_intervals))
    time_features.extend(safe_mean_std(bpm))
    time_features.extend(safe_mean_std(p_wave_amplitudes))
    time_features.extend(safe_mean_std(t_wave_amplitudes))

    winner_features = []

    p_waves = []

    for i in range(0, len(waves_onoffset['ECG_P_Onsets'])):
        time_idx_onset = waves_onoffset['ECG_P_Onsets'][i]
        time_idx_offset = waves_onoffset['ECG_P_Offsets'][i]
        p_waves.extend(ts[time_idx_onset:time_idx_offset])

    t_waves = []

    for i in range(0, len(waves_onoffset['ECG_T_Onsets'])):
        time_idx_onset = waves_onoffset['ECG_T_Onsets'][i]
        time_idx_offset = waves_onoffset['ECG_T_Offsets'][i]
        t_waves.extend(ts[time_idx_onset:time_idx_offset])

    # RR Intervals
    # ============
    rr_intervals = np.diff(ts[r_peaks])
    delta_rr = np.diff(rr_intervals)
    RMSSD = np.sqrt(np.mean(delta_rr**2))
    nn60 = np.sum(np.abs(delta_rr) > 60)
    pNN60 = nn60 / len(rr_intervals) * 100

    # Entropy
    # ============
    SampEnP = entropy_sample(p_waves,
                             delay=1,
                             dimension=2,
                             r=0.2 * np.std(p_waves, ddof=1))
    ApEnP = entropy_approximate(p_waves,
                                delay=1,
                                dimension=2,
                                r=0.2 * np.std(p_waves, ddof=1))
    ApEnR = entropy_approximate(r_peaks,
                                delay=1,
                                dimension=2,
                                r=0.2 * np.std(r_peaks, ddof=1))
    PeEnT = ent.permutation_entropy(t_waves, order=3, delay=1, normalize=False)
    MPeEnT = ent.multiscale_permutation_entropy(t_waves, m=3, delay=1, scale=5)

    # Wavelet Features
    # ====================
    w = pywt.Wavelet("db1")

    #  swt_lvl3 = pywt.swt(filtered_recording, w, 3)
    #  swt_lvl4 = pywt.swt(filtered_recording, w, 4)

    # numpy does not like it if the argument of np.min has length 0
    def safe_mean(arr):
        if len(arr) > 0:
            return [np.mean(arr)]
        else:
            return [0 for _ in range(1)]

    def safe_std(arr):
        if len(arr) > 0:
            return [np.std(arr)]
        else:
            return [0 for _ in range(1)]

    def safe_median(arr):
        if len(arr) > 0:
            return [np.median(arr)]
        else:
            return [0 for _ in range(1)]

    def safe_min(arr):
        if len(arr) > 0:
            return [np.min(arr)]
        else:
            return [0 for _ in range(1)]

    def safe_max(arr):
        if len(arr) > 0:
            return [np.max(arr)]
        else:
            return [0 for _ in range(1)]

    winner_features.extend(safe_min(bpm))  # min heart rate
    winner_features.extend(
        safe_std(MPeEnT))  # T wave multiscale permutation entropy std. dev
    winner_features.extend(safe_max(bpm))  # max heart rate
    winner_features.extend(
        safe_median(MPeEnT))  # T wave multiscale permutation entropy median
    winner_features.append(
        RMSSD
    )  # Root Mean Square of Successive Differences (most popular HRV metric); measures how much variation is in the heart rate
    # cf. https://www.kaggle.com/stetelepta/exploring-heart-rate-variability-using-python

    winner_features.extend(safe_median(rr_intervals))  # RR interval median
    winner_features.extend(safe_mean(bpm))  # Heart Rate µ

    winner_features.append(pNN60)  # pNN60
    #  winner_features.extend(
    #      entropy_shannon(swt_lvl4))  # SWT decomposition level 4 entropy

    winner_features.extend(safe_min(delta_rr))  # Delta RR_min
    winner_features.append(PeEnT)  # T wave permutation entropy std. dev
    winner_features.append(SampEnP)  # P wave sample entropy std. dev
    #  winner_features.extend(
    #      entropy_shannon(swt_lvl3))  # SWT decomposition level 3 entropy
    winner_features.append(ApEnP)  # Median P wave approximate entropy
    winner_features.append(ApEnR)  # R peak approximate entropy

    return time_features + winner_features


# Compute the HRV for every lead
def extract_heart_reate_variabilities(filtered_recording, r_peaks,
                                      signal_frequency):
    hrv_features = []

    hrv_time = nk.hrv_time(r_peaks, sampling_rate=signal_frequency, show=False)
    hrv_features.extend(hrv_time.values[0])

    hrv_freq = nk.hrv_frequency(r_peaks,
                                sampling_rate=signal_frequency,
                                show=False)
    hrv_features.extend(hrv_freq.values[0])

    hrv_nonlinear = nk.hrv_nonlinear(r_peaks,
                                     sampling_rate=signal_frequency,
                                     show=False)
    hrv_features.extend(hrv_nonlinear.values[0])

    return hrv_features


def compute_features(recording, header, leads, signal_frequency):
    recording = preprocess_recording(recording, header, leads,
                                     signal_frequency)

    features = []
    features.append(extract_sex(header))
    features.append(extract_age(header))

    for current_lead in range(len(recording)):
        """-------
            ts : array
                Signal time axis reference (seconds).
            filtered : array
                Filtered ECG signal.
            rpeaks : array
                R-peak location indices.
            templates_ts : array
                Templates time axis reference (seconds).
            templates : array
                Extracted heartbeat templates.
            heart_rate_ts : array
                Heart rate time axis reference (seconds).
            heart_rate : array
                Instantaneous heart rate (bpm).
        """
        signal_time_reference = np.zeros_like(recording[current_lead])
        filtered_recording = np.zeros_like(recording[current_lead])
        r_peaks = np.array([], dtype=int)
        heart_rate = np.array([], dtype=int)
        try:
            (signal_time_reference, filtered_recording, r_peaks, template_ts,
             templates, heart_rate_ts,
             heart_rate) = ecg.ecg(signal=recording[current_lead, :],
                                   sampling_rate=signal_frequency,
                                   show=False)
        except Exception as e:
            features.extend([0] * (2 * 6 + 13 + 14 + 9 + 29))
            continue

        try:
            features.extend(
                extract_time_features(filtered_recording, heart_rate, r_peaks,
                                      signal_time_reference, signal_frequency))
        except Exception as e:
            features.extend([0] * (2 * 6 + 13))

        try:
            features.extend(
                extract_heart_reate_variabilities(filtered_recording, r_peaks,
                                                  signal_frequency))
        except Exception as e:
            features.extend([0] * (14 + 9 + 29))

    features = np.array(features)
    np.nan_to_num(features, copy=False)

    return recording, features


def _load_covariates(args):
    if args.save_covariates:
        filename = os.path.join(
            args.covariates_save_path,
            args.data_path.replace("/", "_") + "-features.npy")
        if os.path.isfile(filename):
            print("loading covariates from", filename)
            covariates = np.load(filename)
            return covariates
    return np.array([])


def precompute_covariates(args):
    # attempt to load covariates
    covariates = np.array([])
    if not args.recompute_covariates:
        covariates = _load_covariates(args)

    # if they were not saved (or we do not want to save them) compute them
    if not covariates.size > 0:
        print("covariates not loaded, starting computation")
        print("this might take a while...")
        header_files, recording_files = find_challenge_files(args.data_path)
        num_samples = len(recording_files)

        def compute_features_parallel(i):
            header = load_header(header_files[i])
            recording = load_recording(recording_files[i])
            _, features = compute_features(recording, header,
                                           data.ecg_stand.twelve_leads,
                                           args.resamp_freq)
            return features

        inputs = tqdm(range(num_samples))
        covariates = Parallel(n_jobs=args.num_processes)(
            delayed(compute_features_parallel)(i) for i in inputs)
        covariates = np.array(covariates)

        if args.save_covariates:
            if not os.path.exists(args.covariates_save_path):
                os.makedirs(args.covariates_save_path)
            filename = os.path.join(
                args.covariates_save_path,
                args.data_path.replace("/", "_") + "-features.npy")
            print("saving covariates as", filename)
            np.save(filename, covariates)

    return covariates


def get_covariates(covariates, leads):
    covariates = np.array(covariates)
    if covariates.size < 1:
        return covariates
    lead_indices = [data.ecg_stand.twelve_leads.index(x) for x in leads]
    n_features_per_lead = (len(covariates) - 2) // 12
    feature_indices = [[0, 1]] + [
        list(
            range(2 + i * n_features_per_lead, 2 +
                  (i + 1) * n_features_per_lead)) for i in lead_indices
    ]
    feature_indices = [
        index for indices in feature_indices for index in indices
    ]
    return covariates[feature_indices]
