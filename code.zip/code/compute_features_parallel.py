import multiprocessing
from joblib import Parallel, delayed
from dev.feature_extractor import FeatureExtractor
from data.ecg_stand import twelve_leads, ecg_classes
from helper_code import *
from tqdm import tqdm

datapath = "ecg_data/all/"
featurepath = "features/"

# num_jobs = multiprocessing.cpu_count() # this seems to give much larger numbers than the number of cores that we can actually use
num_jobs = 16
print("Executing {} threads".format(num_jobs))

fe = FeatureExtractor(250,
                      twelve_leads,
                      use_covariates=True,
                      cache_features=True,
                      recompute_features=False,
                      cache_path=featurepath)

print("loading challenge files")
header_files, recording_files = find_challenge_files(datapath)

num_samples = len(header_files)
num_samples = 100

inputs = tqdm(range(num_samples))


def compute_features(i):
    header = load_header(header_files[i])
    recording = load_recording(recording_files[i])
    recording, features = fe.get_features(recording, header)
    return features

print("Starting to compute features")
test = Parallel(n_jobs=num_jobs)(delayed(compute_features)(i) for i in inputs)
print(test)
