import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.model_selection import train_test_split
from dev.feature_extractor import FeatureExtractor
from data.ecg_stand import twelve_leads, ecg_classes
from helper_code import *
import os

datapath = "ecg_data/all/"
featurepath = "features/"
num_repetitions = 3

feature_names = ["sex", "age"]
time_feature_names = [
    "ratio_qrs_p_dur", "ratio_qrs_t_dur", "pr_intervals", "bpm", "p_wave_amp",
    "t_wave_amp"
]
all_time_feature_names = [
    j + i for i in time_feature_names for j in ["mean_", "std_"]
]
hrv_feature_names = [
    'HRV_RMSSD', 'HRV_MeanNN', 'HRV_SDNN', 'HRV_SDSD', 'HRV_CVNN', 'HRV_CVSD',
    'HRV_MedianNN', 'HRV_MadNN', 'HRV_MCVNN', 'HRV_IQRNN', 'HRV_pNN50',
    'HRV_pNN20', 'HRV_TINN', 'HRV_HTI', 'HRV_ULF', 'HRV_VLF', 'HRV_LF',
    'HRV_HF', 'HRV_VHF', 'HRV_LFHF', 'HRV_LFn', 'HRV_HFn', 'HRV_LnHF',
    'HRV_SD1', 'HRV_SD2', 'HRV_SD1SD2', 'HRV_S', 'HRV_CSI', 'HRV_CVI',
    'HRV_CSI_Modified', 'HRV_PIP', 'HRV_IALS', 'HRV_PSS', 'HRV_PAS', 'HRV_GI',
    'HRV_SI', 'HRV_AI', 'HRV_PI', 'HRV_C1d', 'HRV_C1a', 'HRV_SD1d', 'HRV_SD1a',
    'HRV_C2d', 'HRV_C2a', 'HRV_SD2d', 'HRV_SD2a', 'HRV_Cd', 'HRV_Ca',
    'HRV_SDNNd', 'HRV_SDNNa', 'HRV_ApEn', 'HRV_SampEn'
]
one_lead_names = all_time_feature_names + hrv_feature_names
all_lead_names = [str(i) + "_" + j for i in range(12) for j in one_lead_names]
feature_names.extend(all_lead_names)

fe = FeatureExtractor(250,
                      twelve_leads,
                      use_covariates=True,
                      cache_features=True,
                      recompute_features=False,
                      cache_path=featurepath)

header_files, recording_files = find_challenge_files(datapath)

num_samples = len(header_files)

header = load_header(header_files[0])
recording = load_recording(recording_files[0])
_, features = fe.get_features(recording, header)
num_features = len(features)

X = np.zeros((num_samples, num_features), dtype=np.float32)
y = np.zeros((num_samples, len(ecg_classes)))

errors = 0
for i in range(num_samples):
    if i % 1000 == 0:
        print("processing sample", i, "of", num_samples)
    header = load_header(header_files[i])
    recording = load_recording(recording_files[i])
    _, features = fe.get_features(recording, header)

    if len(features) != 770:
        errors += 1
        print("found recording with error")
        rec_id = get_recording_id(header)
        os.remove('features/' + rec_id + '-features.npy')
        _, features = fe.get_features(recording, header)

    X[i] = features
    current_labels = get_labels(header)
    for label in current_labels:
        if label in ecg_classes:
            j = ecg_classes.index(label)
            y[i, j] = 1

print(np.argwhere(np.isnan(X)))
np.nan_to_num(X, copy=False)

all_importances = np.zeros((num_repetitions, num_features))

for i in range(num_repetitions):
    #  X_train, X_test, y_train, y_test = train_test_split(X,
    #  y,
    #  stratify=None,
    #  random_state=None)
    X_test = X
    y_test = y

    print("fitting random forest classifier")
    forest = RandomForestClassifier(n_estimators=100,
                                    random_state=None,
                                    n_jobs=-1)
    forest.fit(X_test, y_test)

    importances = forest.feature_importances_
    all_importances[i] = importances
    std = np.std([tree.feature_importances_ for tree in forest.estimators_],
                 axis=0)
    forest_importances = pd.Series(importances, index=feature_names)

    df = pd.DataFrame({
        "names": feature_names,
        "importances": importances,
        "std": std
    })
    df.to_csv("runs/importances" + str(i) + ".csv", index=False)

all_std = np.std(all_importances, axis=0)
mean_importances = np.mean(all_importances, axis=0)
df = pd.DataFrame({
    "names": feature_names,
    "importances": mean_importances,
    "std": all_std
})
df.to_csv("runs/importances_all.csv", index=False)

X_train, X_test, y_train, y_test = train_test_split(X,
                                                    y,
                                                    stratify=None,
                                                    random_state=None)

forest = RandomForestClassifier(random_state=42, n_jobs=-1)
forest.fit(X_test, y_test)
result = permutation_importance(forest,
                                X_test,
                                y_test,
                                n_repeats=10,
                                random_state=42,
                                n_jobs=-1)
forest_importances = pd.Series(result.importances_mean, index=feature_names)

#  fig, ax = plt.subplots()
#  forest_importances.plot.bar(yerr=result.importances_std, ax=ax)
#  ax.set_title("Feature importances using permutation on full model")
#  ax.set_ylabel("Mean accuracy decrease")
#  fig.tight_layout()
#  plt.show()

df = pd.DataFrame({
    "names": feature_names,
    "importances": result.importances_mean,
    "std": result.importances_std
})
df.to_csv("runs/importances_perm.csv", index=False)
