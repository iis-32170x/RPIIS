import numpy as np
import torch
import os
import sys
from torch.utils.data import TensorDataset, DataLoader
from helper_code import *
from random import sample
from sklearn.model_selection import KFold
from sklearn.preprocessing import MinMaxScaler

from dev.feature_extractor import preprocess_recording, get_covariates

ecg_classes = ([
    '164889003',  # atrial fibrillation
    '164890007',  # atrial flutter
    '6374002',  # bundle branch block
    '426627000',  # bradycardia
    '733534002',  # complete left bundle branch block  (We score 733534002 and 164909002 as the same diagnosis)
    '713427006',  # complete right bundle branch block  (We score 713427006 and 59118001 as the same diagnosis.)
    '270492004',  # 1st degree av block
    '713426002',  # incomplete right bundle branch block
    '39732003',  # left axis deviation
    '445118002',  # left anterior fascicular block
    '164909002',  # left bundle branch block  (We score 733534002 and 164909002 as the same diagnosis)
    '251146004',  # low qrs voltages
    '698252002',  # nonspecific intraventricular conduction disorder
    '426783006',  # sinus rhythm
    '284470004',  # premature atrial contraction  (We score 284470004 and 63593006 as the same diagnosis.)
    '10370003',  # pacing rhythm
    '365413008',  # poor R wave Progression
    '427172004',  # premature ventricular contractions  (We score 427172004 and 17338001 as the same diagnosis.)
    '164947007',  # prolonged pr interval
    '111975006',  # prolonged qt interval
    '164917005',  # qwave abnormal
    '47665007',  # right axis deviation
    '59118001',  # right bundle branch block  (We score 713427006 and 59118001 as the same diagnosis.)
    '427393009',  # sinus arrhythmia
    '426177001',  # sinus bradycardia
    '427084000',  # sinus tachycardia
    '63593006',  # supraventricular premature beats  (We score 284470004 and 63593006 as the same diagnosis.)
    '164934002',  # t wave abnormal
    '59931005',  # t wave inversion
    '17338001',  # ventricular premature beats  (We score 427172004 and 17338001 as the same diagnosis.)
])

# Define 12, 6, 4, and 2 lead ECG sets.
twelve_leads = ('I', 'II', 'III', 'aVR', 'aVL', 'aVF', 'V1', 'V2', 'V3', 'V4',
                'V5', 'V6')
six_leads = ('I', 'II', 'III', 'aVR', 'aVL', 'aVF')
four_leads = ('I', 'II', 'III', 'V2')
three_leads = ('I', 'II', 'V2')
two_leads = ('I', 'II')


def get_data(args):

    # Read dataset
    dir = args.data_path
    fold_test = args.fold_test
    n_kfold = args.n_kfold

    if args.n_channels == 6:
        which_leads = six_leads
    elif args.n_channels == 4:
        which_leads = four_leads
    elif args.n_channels == 3:
        which_leads = three_leads
    elif args.n_channels == 2:
        which_leads = two_leads
    else:
        which_leads = twelve_leads

    header_files, recording_files = find_challenge_files(dir)

    cv = KFold(n_splits=n_kfold, random_state=42, shuffle=True)
    train_idx, valid_idx = list(iter(cv.split(header_files)))[fold_test]

    # TO DO: split files into train and validation and TEST. This for internal pourpose of testing the models.
    # the code we will give to the challenge will only do training (so nee train and validation to select model)
    hea_val = list(map(header_files.__getitem__, valid_idx))
    rec_val = list(map(recording_files.__getitem__, valid_idx))
    hea_train = list(map(header_files.__getitem__, train_idx))
    rec_train = list(map(recording_files.__getitem__, train_idx))
    if args.use_covariates:
        print("selecting covariates for current leads")
        covariates_tmp = np.array(
            [get_covariates(cov, which_leads) for cov in args.covariates])
        print("selection done")

        covariates_val = list(map(covariates_tmp.__getitem__, valid_idx))
        covariates_train = list(map(covariates_tmp.__getitem__, train_idx))
        print("scaling covariates")
        args.scaler = MinMaxScaler()
        covariates_train = args.scaler.fit_transform(covariates_train)
        covariates_val = args.scaler.transform(covariates_val)
        print("done")
    else:
        covariates_val = [[] for _ in range(len(rec_val))]
        covariates_train = [[] for _ in range(len(rec_train))]

    dataset_train = ecgDataset(dir, hea_train, rec_train, args.resamp_freq,
                               which_leads,
                               covariates_train)  # create your datset
    dataset_test = ecgDataset(dir, hea_val, rec_val, args.resamp_freq,
                              which_leads,
                              covariates_val)  # create your datset

    return dataset_train, dataset_test


def collate_fn_padd(batch):
    '''
    Padds batch of variable length and resampling
    note: it converts things ToTensor manually here since the ToTensor transform
    assume it takes in timesiries rather than arbitrary tensors.
    '''

    ## get sequence lengths
    lengths = torch.tensor([t["ecg"].shape[1] for t in batch])  #.to(device)
    ## padd
    batch_ = [t["ecg"].permute(1, 0) for t in batch]
    batch_ = torch.nn.utils.rnn.pad_sequence(batch_)

    batch_mask = [t["mask"].permute(1, 0) for t in batch]
    batch_mask = torch.nn.utils.rnn.pad_sequence(batch_mask)

    batch_lab = [t["labels"].unsqueeze(0) for t in batch]
    batch_lab = torch.cat(batch_lab, dim=0)

    batch_covariates = [t["covariates"].unsqueeze(0) for t in batch]
    batch_covariates = torch.cat(batch_covariates, dim=0)

    batch_name = [t["name"] for t in batch]

    batch = {
        'ecg': batch_.permute(1, 2, 0),
        'labels': batch_lab,
        'covariates': batch_covariates,
        'name': batch_name,
        'mask': batch_mask.permute(1, 2, 0)
    }

    return batch


class ecgDataset():
    '''replaces TensorDataset '''
    def __init__(self, root_dir, hea_list, rec_list, resamp_freq, which_leads,
                 covariates_all):
        """
        Args:
            root_dir (string): Directory with all the ecg files.
        """
        self.root_dir = root_dir
        self.resamp_freq = resamp_freq

        self.which_leads = which_leads

        self.header_files = hea_list
        self.recording_files = rec_list

        self.classes = ecg_classes

        self.labels = list()  #ecg_classes

        for en, header_file in enumerate(self.header_files):
            header = load_header(header_file)
            self.labels.append(get_labels(header))

        self.num_classes = len(self.classes)

        self.covariates_all = covariates_all

    def __len__(self):
        return len(self.recording_files)

    def __getitem__(self, idx):

        if torch.is_tensor(idx):
            idx = idx.tolist()

        ecg_file_name = self.recording_files[idx]
        hea_file_name = self.header_files[idx]

        #load header and recording
        header = load_header(hea_file_name)
        recording = load_recording(ecg_file_name)

        # get lables from header
        current_labels = get_labels(header)
        labels = np.zeros((self.num_classes), dtype=np.bool)
        for label in current_labels:
            if label in self.classes:
                j = self.classes.index(label)
                labels[j] = 1
        labels = torch.Tensor(labels).float()

        recording = preprocess_recording(recording, header, self.which_leads,
                                         self.resamp_freq)

        covariates = self.covariates_all[idx]

        recording = torch.Tensor(recording).float()
        covariates = torch.Tensor(covariates).float()

        mask = torch.ones(
            (1, recording.shape[1])
        )  # mask is used during trainign to take into account only signal part that is not padded with zeros

        sample = {
            'ecg': recording,
            'labels': labels,
            'covariates': covariates,
            'name': hea_file_name,
            'mask': mask
        }

        return sample
