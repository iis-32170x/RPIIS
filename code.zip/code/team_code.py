#!/usr/bin/env python

# Edit this script to add your team's training code.
# Some functions are *required*, but you can edit most parts of the required functions, remove non-required functions, and add your own functions.

################################################################################
#
# Imported functions and variables
#
################################################################################

# Import functions. These functions are not required. You can change or remove them.
from helper_code import *
import numpy as np, os, sys, joblib
import torch
from utils import *
from dev.developing_suite import *
from models import get_model
from data.ecg_stand import *
from utils.evaluate_model import *
import torch.nn.functional as F
from dev.feature_extractor import precompute_covariates, compute_features
import csv
from data.ecg_stand import ecg_classes

# Define the Challenge lead sets. These variables are not required. You can change or remove them.
twelve_leads = ('I', 'II', 'III', 'aVR', 'aVL', 'aVF', 'V1', 'V2', 'V3', 'V4',
                'V5', 'V6')
six_leads = ('I', 'II', 'III', 'aVR', 'aVL', 'aVF')
four_leads = ('I', 'II', 'III', 'V2')
three_leads = ('I', 'II', 'V2')
two_leads = ('I', 'II')
lead_sets = (twelve_leads, six_leads, four_leads, three_leads, two_leads)

fs_resamp = 250
use_covariates = True

str_args = [
    "--model=Conv1dNet",
    #  "--label-correction",
    #"--start-epoch=15",
    "--alpha-label=0.5",
    "--num-prototypes=10",
    "--loss=ASL",
    "--gamma-neg=3",
    "--gamma-pos=1",
    "--n-covariates=1",
    "--save-model=best",
    "--data=ecg_data",
    "--resamp-freq=" + str(fs_resamp),
    "--mode=train",
    #  "--num-workers=2",
    "--num-processes=-1",
    "--epochs=30",
    "--scheduler=exp",  # feature_branch: no
    "--batch-size=10",  # feature_branch: 16
    "--logstep-train=10",
    "--optimizer=adam",
    "--lr=0.001",
    "--experiment-folder=models/out/",
    #  "--save-covariates",
    "--recompute-covariates",
    "--covariates-save-path=covariates/"
]

if use_covariates:
    str_args.append("--use-covariates")

mod_classes = ([
    '270492004', '164889003', '164890007', '426627000', '713427006',
    '713426002', '445118002', '39732003', '164909002', '251146004',
    '698252002', '10370003', '284470004', '427172004', '164947007',
    '111975006', '164917005', '47665007', '59118001', '427393009', '426177001',
    '426783006', '427084000', '63593006', '164934002', '59931005', '17338001'
])

################################################################################
#
# Training model function
#
################################################################################


# Train your model. This function is *required*. You should edit this function to add your code, but do *not* change the arguments of this function.
def training_code(data_directory, model_directory):

    args = parser.parse_args(str_args)
    args.data_path = data_directory
    args.save_dir = model_directory

    # compute handcrafted features first
    if args.use_covariates:
        args.covariates = precompute_covariates(args)
    else:
        args.covariates = []

    for leads in lead_sets:
        # Start training 12 leads model
        args.model_filename = get_model_filename(
            leads)  #twelve_lead_model_filename
        args.n_channels = len(leads)
        developingSuite = DevelopingSuite(args)
        print(">>> Start Training " + str(args.n_channels) +
              " lead model... \n ")
        developingSuite.train_and_eval()
        break


################################################################################
#
# File I/O functions
#
################################################################################


# Load a trained model. This function is *required*. You should edit this function to add your code, but do *not* change the arguments of this function.
def load_model(model_directory, leads):
    filename = os.path.join(model_directory, get_model_filename(leads))
    data_model = torch.load(filename)
    args = data_model['args']
    model = get_model(args)
    model.load_state_dict(data_model['model_state_dict'])

    return model, args


# Define the filename(s) for the trained models.
def get_model_filename(leads):
    sorted_leads = sort_leads(leads)
    return 'model_' + '-'.join(sorted_leads) + '.pth'


################################################################################
#
# Running trained model function
#
################################################################################


# Generic function for running a trained model.
def run_model(model, header, recording):
    args = model[1]
    model = model[0]
    leads = get_leads(header)

    if not args.use_covariates:
        recording = preprocess_recording(recording, header, leads,
                                     fs_resamp)
        covariates = []
    else:
        recording, covariates = compute_features(recording, header, leads, fs_resamp)
        covariates = args.scaler.transform(covariates.reshape(1, -1)).flatten()

    print('^^^^^^^^^^^^^^^^^^^torch.cuda.is_available()^^^^^^^^^^^^^^^^^^^^^^^^^^^')
    print(torch.cuda.is_available())
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    rec = torch.tensor(recording).float().to(device)
    covariates = torch.tensor(covariates).float().to(device)

    mask = torch.ones((1, rec.shape[1])).to(device)

    x_t = rec.unsqueeze(0)
    covariates = covariates.unsqueeze(0)
    mask = mask.unsqueeze(0)

    x_t, covariates, mask = x_t.to(device), covariates.to(device), mask.to(
        device)

    # evaluation
    model.to(device)
    model.eval()

    y_pred = model(x_t, covariates, mask).squeeze()
    y_pred_binary = 0.5 * (torch.sign(torch.sigmoid(y_pred) - 0.5) + 1)
    prdict_prob = torch.sigmoid(y_pred)

    # outputs_all = torch.cat((outputs_all,y_pred_binary),0)
    # score_all = torch.cat((score_all,y_pred ),0)

    # Predict labels and probabilities.
    labels = np.asarray(y_pred_binary.cpu().detach().numpy(), dtype=np.int)
    probabilities = np.asarray(prdict_prob.cpu().detach().numpy(),
                               dtype=np.float32)

    return ecg_classes, labels, probabilities
