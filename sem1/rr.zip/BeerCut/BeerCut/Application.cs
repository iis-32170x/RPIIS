using BeerCut.Algorithms;
using BeerCut.Core;
using BeerCut.CustomMath;
using BeerCut.IO;

namespace BeerCut;

public class Application
{
    private readonly InputReader _inputReader;
    private readonly Converter _converter;
    private readonly IDataProcessor _dataProcessor;
    private readonly SummaryLogBuilder _summaryLogBuilder;
    private readonly OutputWriter _outputWriter;

    public Application(InputReader inputReader, Converter converter,
        IDataProcessor dataProcessor, SummaryLogBuilder summaryLogBuilder,
        OutputWriter outputWriter)
    {
        _inputReader = inputReader;
        _converter = converter;
        _dataProcessor = dataProcessor;
        _summaryLogBuilder = summaryLogBuilder;
        _outputWriter = outputWriter;
    }

    public void Run()
    {
        bool success = _inputReader.TryToGetFiles(out string[] files,
            out string exceptionMessage);

        if (!success)
        {
            throw new Exception(exceptionMessage);
        }

        foreach (string file in files)
        {
            ProcessFile(file);
        }

        string[] applicationReportList = _summaryLogBuilder.Build();
        _outputWriter.WriteLines(applicationReportList);
        _outputWriter.WriteMessage("Application successfully performed");
    }

    private void ProcessFile(string file)
    {
        string[] inputLines = _inputReader.ReadAllLines(file);
        IJaggedArray jaggedArray = _converter.ConvertLinesToMatrix(inputLines);
        string[] report = _dataProcessor.Process(jaggedArray);
        _summaryLogBuilder.Add(file, report);
    }
}