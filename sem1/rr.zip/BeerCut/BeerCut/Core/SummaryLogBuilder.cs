namespace BeerCut.Core;

public class SummaryLogBuilder
{
    private readonly List<string> _reportLines = new();
    private readonly int _headerLength;
    private readonly int _spacingBetweenReports;
    private readonly char _bodySymbol;
    private readonly char _fileBar;
    private readonly object _space;

    public SummaryLogBuilder(int headerLength, int spacingBetweenReports,
        char reportBodySymbol, char fileBar, char whiteSpace)
    {
        _headerLength = headerLength;
        _spacingBetweenReports = spacingBetweenReports;
        _bodySymbol = reportBodySymbol;
        _fileBar = fileBar;
        _space = whiteSpace;
    }

    public void Add(string fileName, params string[] report)
    {
        _reportLines.Add($"{_fileBar}file{_fileBar}{_space}{fileName}");
        _reportLines.Add(GetLineSeparator());
        _reportLines.AddRange(report);
        _reportLines.Add(GetLineSeparator());
        AddSpacing();
    }

    public string[] Build()
    {
        RemoveLastSpacing();

        return _reportLines.ToArray();
    }

    private void AddSpacing()
    {
        for (int i = 0; i < _spacingBetweenReports; i++)
        {
            _reportLines.Add(string.Empty);
        }
    }

    private void RemoveLastSpacing()
    {
        int trashBeginningIndex = _reportLines.Count - _spacingBetweenReports;
        _reportLines.RemoveRange(trashBeginningIndex, _spacingBetweenReports);
    }

    private string GetLineSeparator()
    {
        return new String(_bodySymbol, _headerLength);
    }
}