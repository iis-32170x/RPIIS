using BeerCut.CustomMath;

namespace BeerCut.Core;

public class Converter
{
    private readonly char _separator;

    public Converter(char separator)
    {
        _separator = separator;
    }

    public IJaggedArray ConvertLinesToMatrix(string[] lines)
    {
        int columnLength = lines[0].Split(_separator).Length;
        Matrix matrix = new Matrix(columnLength);

        foreach (string line in lines)
        {
            string[] symbols = line.Split(_separator);
            List<int> rowValues = new List<int>(lines.Length / 2);

            foreach (string symbol in symbols)
            {
                if (int.TryParse(symbol, out int value))
                {
                    rowValues.Add(value);
                }
                else
                {
                    throw new Exception($"Failed to convert value: {symbol}");
                }
            }

            matrix.AddRow(rowValues);
        }

        return matrix;
    }
}