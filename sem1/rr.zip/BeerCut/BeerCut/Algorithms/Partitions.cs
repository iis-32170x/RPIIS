namespace BeerCut.Algorithms;

public struct Partitions
{
    public readonly int[] PartA;
    public readonly int[] PartB;

    public Partitions(int[] partA, int[] partB)
    {
        PartA = partA;
        PartB = partB;
    }
}