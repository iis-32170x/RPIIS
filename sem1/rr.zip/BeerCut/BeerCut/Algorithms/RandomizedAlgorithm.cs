using BeerCut.CustomMath;

namespace BeerCut.Algorithms;

public class RandomizedAlgorithm : IDataProcessor
{
    private int _cutValue;

    public string[] Process(IJaggedArray jaggedArray)
    {
        int[,] multidimensionalArray = jaggedArray.ToMultidimensionalArray();
        Partitions partitions = FindMaxCut(multidimensionalArray);

        string[] lines =
        {
            "Partition A: " + string.Join(", ", partitions.PartA),
            "Partition B: " + string.Join(", ", partitions.PartB),
            "Max-Cut value: " + _cutValue
        };

        return lines;
    }

    private int GetCutWeight(int[,] matrix, Partitions partitions)
    {
        int[] partitionA = partitions.PartA;
        int[] partitionB = partitions.PartB;
        int cutA = 0;
        int cutB = 0;

        foreach (int vertexA in partitionA)
        {
            foreach (int vertexB in partitionB)
            {
                cutA += GetEdgeBetween(vertexA, vertexB);
            }
        }

        foreach (int vertexB in partitionB)
        {
            foreach (int vertexA in partitionA)
            {
                cutB += GetEdgeBetween(vertexB, vertexA);
            }
        }

        return int.Max(cutA, cutB);

        int GetEdgeBetween(int vertexA, int vertexB)
        {
            int result;

            if (matrix[vertexA, vertexB] == 0)
            {
                result = matrix[vertexB, vertexA];
            }
            else
            {
                result = matrix[vertexA, vertexB];
            }

            return result;
        }
    }

    private Partitions FindMaxCut(int[,] matrix)
    {
        int quantityOfVertices = matrix.GetLength(0);
        bool[] partitionSeparation = GetInitialSeparation();
        int currentCut = GetCutWeight(matrix, SeparationToPartitions());

        for (int i = 0; i < quantityOfVertices; i++)
        {
            partitionSeparation[i] = !partitionSeparation[i];
            int temporaryCut = GetCutWeight(matrix, SeparationToPartitions());

            if (temporaryCut > currentCut)
            {
                currentCut = temporaryCut;
            }
            else
            {
                partitionSeparation[i] = !partitionSeparation[i];
            }
        }

        _cutValue = currentCut;

        return SeparationToPartitions();

        bool[] GetInitialSeparation()
        {
            Random random = new Random();
            bool[] array = new bool[quantityOfVertices];

            for (int i = 0; i < quantityOfVertices; i++)
            {
                bool insidePartitionA = random.NextDouble() >= 0.5;
                array[i] = insidePartitionA;
            }

            return array;
        }

        Partitions SeparationToPartitions()
        {
            List<int> partitionA = new List<int>();
            List<int> partitionB = new List<int>();

            for (int i = 0; i < partitionSeparation.Length; i++)
            {
                bool vertexInsideA = partitionSeparation[i];
                if (vertexInsideA)
                {
                    partitionA.Add(i);
                }
                else
                {
                    partitionB.Add(i);
                }
            }

            return new Partitions(partitionA.ToArray(), partitionB.ToArray());
        }
    }
}