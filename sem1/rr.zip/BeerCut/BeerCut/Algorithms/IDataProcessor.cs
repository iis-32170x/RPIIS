using BeerCut.CustomMath;

namespace BeerCut.Algorithms;

public interface IDataProcessor
{
    public string[] Process(IJaggedArray jaggedArray);
}