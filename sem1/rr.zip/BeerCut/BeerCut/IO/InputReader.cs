namespace BeerCut.IO;

public class InputReader
{
    private readonly string _directory;
    private readonly string _searchPattern;

    public InputReader(string directory, string searchPattern)
    {
        _directory = directory;
        _searchPattern = searchPattern;
    }

    public bool TryToGetFiles(out string[] files, out string errorMessage)
    {
        if (!Directory.Exists(_directory))
        {
            files = new[] { string.Empty };
            errorMessage = $"[{_directory}] doesn't exist";

            return false;
        }

        files = Directory
            .EnumerateFiles(_directory, _searchPattern)
            .ToArray();

        if (files.Length <= 0)
        {
            files = new[] { string.Empty };
            errorMessage =
                $"[{_directory}] isn't contain {_searchPattern} files";

            return false;
        }
        errorMessage = string.Empty;

        return true;
    }

    public string[] ReadAllLines(string path)
    {
        return File.ReadAllLines(path);
    }
}