namespace BeerCut.IO;

public class OutputWriter
{
    private readonly string _filePath;
    private readonly bool _debugToConsole;

    public OutputWriter(string filePath, bool debugToConsole)
    {
        _filePath = filePath;
        _debugToConsole = debugToConsole;
    }

    public void WriteLines(string[] lines)
    {
        if (_debugToConsole)
        {
            foreach (string line in lines)
            {
                Console.WriteLine(line);
            }
        }
        else
        {
            File.WriteAllLines(_filePath, lines);
        }
    }

    public void WriteMessage(string line)
    {
        Console.WriteLine(line);
    }
}