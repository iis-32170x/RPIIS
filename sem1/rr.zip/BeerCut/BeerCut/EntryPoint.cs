﻿using BeerCut.Algorithms;
using BeerCut.Core;
using BeerCut.IO;

namespace BeerCut;

internal static class EntryPoint
{
    private const string Directory = "D:\\_";
    private const string ReportFile = "D:\\Report.txt";
    private const string FileExtension = "*.txt";
    private const char Whitespace = ' ';

    private static Application InitializeApplication()
    {
        OutputWriter outputWriter = new(ReportFile, false);

        SummaryLogBuilder summaryLogBuilder = new SummaryLogBuilder(
            50,
            2,
            '\u2550',
            '\u2551',
            Whitespace
        );

        Application application = new Application(
            new InputReader(Directory, FileExtension),
            new Converter(Whitespace),
            new RandomizedAlgorithm(),
            summaryLogBuilder,
            outputWriter
        );

        return application;
    }

    public static void Main()
    {
        Application application = InitializeApplication();
        application.Run();
    }
}