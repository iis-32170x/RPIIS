namespace BeerCut.CustomMath;

public interface IJaggedArray
{
    public int Get(int i, int j);

    public int[,] ToMultidimensionalArray();
}