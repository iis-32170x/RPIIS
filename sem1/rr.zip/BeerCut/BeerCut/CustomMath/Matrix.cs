namespace BeerCut.CustomMath;

public readonly struct Matrix : IJaggedArray
{
    private readonly List<List<int>> _matrix;
    private readonly int _columnLength;

    public Matrix(int columnLength)
    {
        _matrix = new List<List<int>>(columnLength);
        _columnLength = columnLength;
    }

    public void AddRow(List<int> list)
    {
        _matrix.Add(list);
    }

    public int Get(int i, int j)
    {
        return _matrix[i][j];
    }

    public int[,] ToMultidimensionalArray()
    {
        int[,] array = new int[_columnLength, _columnLength];

        for (int i = 0; i < _matrix.Count; i++)
        {
            for (int j = 0; j < _matrix[i].Count; j++)
            {
                array[i, j] = _matrix[i][j];
            }
        }

        return array;
    }
}